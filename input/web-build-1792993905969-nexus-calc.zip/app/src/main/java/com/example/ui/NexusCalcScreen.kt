package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calc.FinanceEngine
import com.example.calc.MathEngine
import com.example.calc.UnitConverter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HistoryEntry(val timestamp: String, val expression: String, val result: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexusCalcScreen(modifier: Modifier = Modifier) {
  val context = LocalContext.current
  val vibrator = remember(context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
      vm?.defaultVibrator
    } else {
      @Suppress("DEPRECATION")
      context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
  }

  fun haptic(ms: Long = 15) {
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        @Suppress("DEPRECATION")
        vibrator?.vibrate(ms)
      }
    } catch (_: Exception) {}
  }

  fun copyToClipboard(text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Nexus Calc", text))
    Toast.makeText(context, "Copied: $text", Toast.LENGTH_SHORT).show()
  }

  // App Theme & Navigation State
  var isDarkTheme by remember { mutableStateOf(true) }
  var currentTab by remember { mutableStateOf("standard") } // standard, scientific, converter, finance, history
  var precision by remember { mutableStateOf("auto") } // auto, 2, 4, 6
  var isDegreeMode by remember { mutableStateOf(true) }
  var isSecondFn by remember { mutableStateOf(false) }

  // BackHandler for sub tabs
  BackHandler(enabled = currentTab != "standard") {
    currentTab = "standard"
  }

  // Calculator State
  var expression by remember { mutableStateOf("") }
  var resultText by remember { mutableStateOf("0") }
  var isEvaluated by remember { mutableStateOf(false) }
  var hasError by remember { mutableStateOf(false) }
  var memory by remember { mutableStateOf(0.0) }
  val historyList = remember { mutableStateListOf<HistoryEntry>() }

  // Live Preview Calculation
  val livePreview by remember(expression, isDegreeMode, precision, isEvaluated) {
    derivedStateOf {
      if (expression.isBlank() || isEvaluated || hasError) ""
      else {
        try {
          var cleanExpr = expression
          val openCount = cleanExpr.count { it == '(' }
          val closeCount = cleanExpr.count { it == ')' }
          if (openCount > closeCount) cleanExpr += ")".repeat(openCount - closeCount)
          val v = MathEngine.evaluate(cleanExpr, isDegreeMode)
          "= " + MathEngine.formatNumber(v, precision)
        } catch (_: Exception) { "" }
      }
    }
  }

  fun calculate() {
    if (expression.isBlank()) return
    try {
      val raw = MathEngine.evaluate(expression, isDegreeMode)
      val formatted = MathEngine.formatNumber(raw, precision)
      val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
      historyList.add(0, HistoryEntry(time, expression, formatted))
      resultText = formatted
      isEvaluated = true
      hasError = false
      haptic(30)
    } catch (e: Exception) {
      hasError = true
      resultText = e.message ?: "Error"
      haptic(60)
    }
  }

  fun appendToken(token: String) {
    haptic(15)
    if (isEvaluated || hasError) {
      expression = ""
      isEvaluated = false
      hasError = false
    }
    if (expression == "0" && token != ".") {
      expression = token
    } else {
      expression += token
    }
  }

  fun appendOperator(op: String) {
    haptic(15)
    if (isEvaluated) {
      expression = resultText
      isEvaluated = false
    }
    if (expression.isEmpty()) {
      if (op == "−" || op == "-") {
        expression = "−"
        return
      }
      expression = "0"
    }
    if (expression.endsWith("+") || expression.endsWith("−") || expression.endsWith("×") || expression.endsWith("÷") || expression.endsWith("^")) {
      expression = expression.dropLast(1) + op
    } else {
      expression += op
    }
  }

  val backgroundColor = if (isDarkTheme) Color(0xFF090D16) else Color(0xFFF1F5F9)
  val surfaceColor = if (isDarkTheme) Color(0xFF111726) else Color(0xFFFFFFFF)
  val textColor = if (isDarkTheme) Color(0xFFF1F5F9) else Color(0xFF0F172A)
  val accentColor = Color(0xFF0284C7)

  Surface(
    modifier = modifier.fillMaxSize(),
    color = backgroundColor
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
      // 1. Top Header Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(surfaceColor)
          .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(34.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(accentColor),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Calculate, contentDescription = "Logo", tint = Color.White, modifier = Modifier.size(20.dp))
          }
          Spacer(Modifier.width(8.dp))
          Text(
            text = "NEXUS CALC",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 17.sp,
            color = textColor
          )
          Spacer(Modifier.width(6.dp))
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = accentColor.copy(alpha = 0.15f)
          ) {
            Text("PRO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = accentColor, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          AssistChip(
            onClick = {
              isDegreeMode = !isDegreeMode
              haptic(15)
            },
            label = { Text(if (isDegreeMode) "DEG" else "RAD", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = AssistChipDefaults.assistChipColors(containerColor = surfaceColor)
          )
          Spacer(Modifier.width(4.dp))
          IconButton(
            onClick = {
              isDarkTheme = !isDarkTheme
              haptic(15)
            },
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
              contentDescription = "Theme Toggle",
              tint = if (isDarkTheme) Color(0xFFFBBF24) else Color(0xFF475569)
            )
          }
        }
      }

      Spacer(Modifier.height(8.dp))

      // 2. Navigation Tabs
      ScrollableTabRow(
        selectedTabIndex = when (currentTab) {
          "standard" -> 0
          "scientific" -> 1
          "converter" -> 2
          "finance" -> 3
          else -> 4
        },
        containerColor = surfaceColor,
        contentColor = accentColor,
        edgePadding = 6.dp,
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(24.dp))
      ) {
        listOf("standard" to "Standard", "scientific" to "Scientific", "converter" to "Converter", "finance" to "Finance", "history" to "History").forEach { (tabId, label) ->
          Tab(
            selected = currentTab == tabId,
            onClick = {
              currentTab = tabId
              haptic(15)
            },
            text = { Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
          )
        }
      }

      Spacer(Modifier.height(8.dp))

      // 3. Tab Content
      when (currentTab) {
        "standard", "scientific" -> {
          // Calculator Screen Display
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = surfaceColor)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
            ) {
              // Indicators
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  Badge(containerColor = accentColor.copy(alpha = 0.2f), contentColor = accentColor) {
                    Text(if (isDegreeMode) "DEG" else "RAD", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  }
                  if (memory != 0.0) {
                    Badge(containerColor = Color(0xFF10B981).copy(alpha = 0.2f), contentColor = Color(0xFF10B981)) {
                      Text("M", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                  if (hasError) {
                    Badge(containerColor = Color(0xFFEF4444).copy(alpha = 0.2f), contentColor = Color(0xFFEF4444)) {
                      Text("ERR", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }

                IconButton(
                  onClick = { copyToClipboard(resultText) },
                  modifier = Modifier.size(28.dp)
                ) {
                  Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy", tint = Color.Gray, modifier = Modifier.size(16.dp))
                }
              }

              Spacer(Modifier.height(4.dp))

              // Expression row (scrollable)
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .horizontalScroll(rememberScrollState(), reverseScrolling = true),
                horizontalArrangement = Arrangement.End
              ) {
                Text(
                  text = expression.ifEmpty { " " },
                  fontFamily = FontFamily.Monospace,
                  fontSize = 15.sp,
                  color = textColor.copy(alpha = 0.7f),
                  textAlign = TextAlign.End
                )
              }

              Spacer(Modifier.height(2.dp))

              // Result row
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .horizontalScroll(rememberScrollState(), reverseScrolling = true),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.Bottom
              ) {
                Text(
                  text = resultText,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  fontSize = 32.sp,
                  color = if (hasError) Color(0xFFEF4444) else textColor,
                  textAlign = TextAlign.End
                )
              }

              // Live preview
              if (livePreview.isNotEmpty()) {
                Text(
                  text = livePreview,
                  fontFamily = FontFamily.Monospace,
                  fontSize = 13.sp,
                  color = accentColor,
                  modifier = Modifier.align(Alignment.End)
                )
              }
            }
          }

          Spacer(Modifier.height(6.dp))

          // Memory row
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(surfaceColor)
              .padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            listOf("MC", "MR", "M+", "M-", "MS").forEach { memAction ->
              TextButton(
                onClick = {
                  haptic(15)
                  val cur = resultText.replace(",", "").toDoubleOrNull() ?: 0.0
                  when (memAction) {
                    "MC" -> { memory = 0.0; Toast.makeText(context, "Memory Cleared", Toast.LENGTH_SHORT).show() }
                    "MR" -> { appendToken(memory.toString()); Toast.makeText(context, "Recalled: $memory", Toast.LENGTH_SHORT).show() }
                    "M+" -> { memory += cur; Toast.makeText(context, "Added: $memory", Toast.LENGTH_SHORT).show() }
                    "M-" -> { memory -= cur; Toast.makeText(context, "Subtracted: $memory", Toast.LENGTH_SHORT).show() }
                    "MS" -> { memory = cur; Toast.makeText(context, "Saved: $memory", Toast.LENGTH_SHORT).show() }
                  }
                },
                modifier = Modifier.weight(1f)
              ) {
                Text(memAction, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = accentColor)
              }
            }
          }

          Spacer(Modifier.height(6.dp))

          // Scientific Pad if tab is scientific
          if (currentTab == "scientific") {
            Card(
              modifier = Modifier.fillMaxWidth(),
              colors = CardDefaults.cardColors(containerColor = surfaceColor)
            ) {
              Column(modifier = Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  SciButton(text = if (isSecondFn) "sin⁻¹" else "sin", modifier = Modifier.weight(1f)) { appendToken(if (isSecondFn) "asin(" else "sin(") }
                  SciButton(text = if (isSecondFn) "cos⁻¹" else "cos", modifier = Modifier.weight(1f)) { appendToken(if (isSecondFn) "acos(" else "cos(") }
                  SciButton(text = if (isSecondFn) "tan⁻¹" else "tan", modifier = Modifier.weight(1f)) { appendToken(if (isSecondFn) "atan(" else "tan(") }
                  SciButton(text = "ln", modifier = Modifier.weight(1f)) { appendToken("ln(") }
                  SciButton(text = "log", modifier = Modifier.weight(1f)) { appendToken("log(") }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  SciButton(text = "√x", modifier = Modifier.weight(1f)) { appendToken("sqrt(") }
                  SciButton(text = "x²", modifier = Modifier.weight(1f)) { appendToken("^2") }
                  SciButton(text = "xʸ", modifier = Modifier.weight(1f)) { appendOperator("^") }
                  SciButton(text = "π", modifier = Modifier.weight(1f)) { appendToken("π") }
                  SciButton(text = "e", modifier = Modifier.weight(1f)) { appendToken("e") }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  SciButton(text = "n!", modifier = Modifier.weight(1f)) { appendToken("!") }
                  SciButton(text = "1/x", modifier = Modifier.weight(1f)) { appendToken("1/(") }
                  SciButton(text = "|x|", modifier = Modifier.weight(1f)) { appendToken("abs(") }
                  SciButton(text = "mod", modifier = Modifier.weight(1f)) { appendOperator("%") }
                  SciButton(text = if (isSecondFn) "1st" else "2nd", isHighlight = isSecondFn, modifier = Modifier.weight(1f)) { isSecondFn = !isSecondFn }
                }
              }
            }
            Spacer(Modifier.height(6.dp))
          }

          // Standard Keypad Grid
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              KeypadButton(text = "AC", color = Color(0xFFEF4444), isAction = true, modifier = Modifier.weight(1f)) {
                expression = ""
                resultText = "0"
                isEvaluated = false
                hasError = false
                haptic(15)
              }
              KeypadButton(text = "(", isAction = true, modifier = Modifier.weight(1f)) { appendToken("(") }
              KeypadButton(text = ")", isAction = true, modifier = Modifier.weight(1f)) { appendToken(")") }
              KeypadButton(text = "⌫", isAction = true, modifier = Modifier.weight(1f)) {
                if (expression.isNotEmpty()) expression = expression.dropLast(1)
                haptic(15)
              }
            }
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              KeypadButton(text = "%", isAction = true, modifier = Modifier.weight(1f)) {
                try {
                  val v = MathEngine.evaluate(expression, isDegreeMode) / 100.0
                  expression = v.toString()
                  resultText = MathEngine.formatNumber(v, precision)
                } catch (_: Exception) {}
              }
              KeypadButton(text = "±", isAction = true, modifier = Modifier.weight(1f)) {
                expression = if (expression.startsWith("−(")) expression.removePrefix("−(").removeSuffix(")")
                else "−($expression)"
              }
              KeypadButton(text = "÷", isOperator = true, modifier = Modifier.weight(1f)) { appendOperator("÷") }
              KeypadButton(text = "×", isOperator = true, modifier = Modifier.weight(1f)) { appendOperator("×") }
            }
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              KeypadButton(text = "7", modifier = Modifier.weight(1f)) { appendToken("7") }
              KeypadButton(text = "8", modifier = Modifier.weight(1f)) { appendToken("8") }
              KeypadButton(text = "9", modifier = Modifier.weight(1f)) { appendToken("9") }
              KeypadButton(text = "−", isOperator = true, modifier = Modifier.weight(1f)) { appendOperator("−") }
            }
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              KeypadButton(text = "4", modifier = Modifier.weight(1f)) { appendToken("4") }
              KeypadButton(text = "5", modifier = Modifier.weight(1f)) { appendToken("5") }
              KeypadButton(text = "6", modifier = Modifier.weight(1f)) { appendToken("6") }
              KeypadButton(text = "+", isOperator = true, modifier = Modifier.weight(1f)) { appendOperator("+") }
            }
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              KeypadButton(text = "1", modifier = Modifier.weight(1f)) { appendToken("1") }
              KeypadButton(text = "2", modifier = Modifier.weight(1f)) { appendToken("2") }
              KeypadButton(text = "3", modifier = Modifier.weight(1f)) { appendToken("3") }
              KeypadButton(text = "00", modifier = Modifier.weight(1f)) { appendToken("00") }
            }
            Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              KeypadButton(text = "0", modifier = Modifier.weight(1f)) { appendToken("0") }
              KeypadButton(text = ".", modifier = Modifier.weight(1f)) { appendToken(".") }
              KeypadButton(text = "=", isEquals = true, modifier = Modifier.weight(2f)) { calculate() }
            }
          }
        }

        "converter" -> {
          UnitConverterScreen(surfaceColor = surfaceColor, textColor = textColor, accentColor = accentColor, onCopy = ::copyToClipboard)
        }

        "finance" -> {
          FinanceSuiteScreen(surfaceColor = surfaceColor, textColor = textColor, accentColor = accentColor)
        }

        "history" -> {
          HistoryScreen(
            historyList = historyList,
            surfaceColor = surfaceColor,
            textColor = textColor,
            accentColor = accentColor,
            onReuse = { entry ->
              expression = entry.expression
              resultText = entry.result
              currentTab = "standard"
            },
            onCopy = ::copyToClipboard,
            onClear = { historyList.clear() }
          )
        }
      }
    }
  }
}

@Composable
fun KeypadButton(
  text: String,
  modifier: Modifier = Modifier,
  isOperator: Boolean = false,
  isAction: Boolean = false,
  isEquals: Boolean = false,
  color: Color? = null,
  onClick: () -> Unit
) {
  val bg = when {
    isEquals -> Color(0xFF0284C7)
    isOperator -> Color(0xFF1E3A8A)
    isAction -> Color(0xFF334155)
    else -> Color(0xFF1E293B)
  }
  val fg = color ?: when {
    isEquals -> Color.White
    isOperator -> Color(0xFFBFDBFE)
    isAction -> Color(0xFFCBD5E1)
    else -> Color.White
  }

  Box(
    modifier = modifier
      .fillMaxHeight()
      .clip(RoundedCornerShape(14.dp))
      .background(bg)
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = text,
      color = fg,
      fontSize = if (text.length > 2) 16.sp else 22.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
fun SciButton(
  text: String,
  modifier: Modifier = Modifier,
  isHighlight: Boolean = false,
  onClick: () -> Unit
) {
  Box(
    modifier = modifier
      .height(38.dp)
      .clip(RoundedCornerShape(8.dp))
      .background(if (isHighlight) Color(0xFF0284C7) else Color(0xFF131C31))
      .clickable(onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Text(text, color = Color(0xFF7DD3FC), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitConverterScreen(
  surfaceColor: Color,
  textColor: Color,
  accentColor: Color,
  onCopy: (String) -> Unit
) {
  var selectedCategory by remember { mutableStateOf("length") }
  val category = remember(selectedCategory) { UnitConverter.categories.find { it.id == selectedCategory }!! }
  var fromUnitId by remember(selectedCategory) { mutableStateOf(category.defaultFrom) }
  var toUnitId by remember(selectedCategory) { mutableStateOf(category.defaultTo) }
  var inputValStr by remember { mutableStateOf("1") }

  var fromMenuExpanded by remember { mutableStateOf(false) }
  var toMenuExpanded by remember { mutableStateOf(false) }

  val inputVal = inputValStr.toDoubleOrNull() ?: 0.0
  val resultVal = remember(selectedCategory, inputVal, fromUnitId, toUnitId) {
    UnitConverter.convert(selectedCategory, inputVal, fromUnitId, toUnitId)
  }

  val fromUnitName = category.units.find { it.id == fromUnitId }?.name ?: fromUnitId
  val toUnitName = category.units.find { it.id == toUnitId }?.name ?: toUnitId

  Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    // Categories pill row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      UnitConverter.categories.forEach { cat ->
        FilterChip(
          selected = selectedCategory == cat.id,
          onClick = {
            selectedCategory = cat.id
            fromUnitId = cat.defaultFrom
            toUnitId = cat.defaultTo
          },
          label = { Text(cat.name, fontSize = 12.sp) }
        )
      }
    }

    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = surfaceColor)) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
          value = inputValStr,
          onValueChange = { inputValStr = it },
          label = { Text("Value to Convert") },
          modifier = Modifier.fillMaxWidth()
        )

        // From Unit Selector
        Box {
          OutlinedCard(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { fromMenuExpanded = true }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("From", fontSize = 11.sp, color = Color.Gray)
                Text(fromUnitName, fontWeight = FontWeight.Bold, color = textColor)
              }
              Icon(Icons.Default.ArrowDropDown, contentDescription = "Select From Unit")
            }
          }
          DropdownMenu(
            expanded = fromMenuExpanded,
            onDismissRequest = { fromMenuExpanded = false }
          ) {
            category.units.forEach { u ->
              DropdownMenuItem(
                text = { Text(u.name) },
                onClick = {
                  fromUnitId = u.id
                  fromMenuExpanded = false
                }
              )
            }
          }
        }

        // Swap button
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
          IconButton(
            onClick = {
              val tmp = fromUnitId
              fromUnitId = toUnitId
              toUnitId = tmp
            },
            modifier = Modifier
              .size(40.dp)
              .clip(RoundedCornerShape(20.dp))
              .background(accentColor.copy(alpha = 0.15f))
          ) {
            Icon(Icons.Default.SwapVert, contentDescription = "Swap Units", tint = accentColor)
          }
        }

        // To Unit Selector
        Box {
          OutlinedCard(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { toMenuExpanded = true }
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("To", fontSize = 11.sp, color = Color.Gray)
                Text(toUnitName, fontWeight = FontWeight.Bold, color = textColor)
              }
              Icon(Icons.Default.ArrowDropDown, contentDescription = "Select To Unit")
            }
          }
          DropdownMenu(
            expanded = toMenuExpanded,
            onDismissRequest = { toMenuExpanded = false }
          ) {
            category.units.forEach { u ->
              DropdownMenuItem(
                text = { Text(u.name) },
                onClick = {
                  toUnitId = u.id
                  toMenuExpanded = false
                }
              )
            }
          }
        }

        // Result Card
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = accentColor.copy(alpha = 0.1f))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("Converted Result", fontSize = 12.sp, color = Color.Gray)
              Text(
                text = String.format(Locale.US, "%,.6f", resultVal).trimEnd('0').trimEnd('.'),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor
              )
            }
            IconButton(onClick = { onCopy(resultVal.toString()) }) {
              Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy", tint = accentColor)
            }
          }
        }
      }
    }
  }
}

@Composable
fun FinanceSuiteScreen(surfaceColor: Color, textColor: Color, accentColor: Color) {
  var activeTool by remember { mutableStateOf("emi") }

  Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
      listOf(
        "emi" to "EMI Loan",
        "interest" to "Interest",
        "gst" to "GST Tax",
        "discount" to "Discount",
        "profit" to "Profit & Loss",
        "sip" to "SIP Wealth"
      ).forEach { (id, label) ->
        FilterChip(
          selected = activeTool == id,
          onClick = { activeTool = id },
          label = { Text(label, fontSize = 12.sp) }
        )
      }
    }

    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = surfaceColor)) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        when (activeTool) {
          "emi" -> {
            var loanAmount by remember { mutableStateOf("50000") }
            var interestRate by remember { mutableStateOf("8.5") }
            var tenureYears by remember { mutableStateOf("5") }

            OutlinedTextField(value = loanAmount, onValueChange = { loanAmount = it }, label = { Text("Loan Amount ($)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = interestRate, onValueChange = { interestRate = it }, label = { Text("Annual Interest Rate (%)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = tenureYears, onValueChange = { tenureYears = it }, label = { Text("Tenure (Years)") }, modifier = Modifier.fillMaxWidth())

            val P = loanAmount.toDoubleOrNull() ?: 0.0
            val R = interestRate.toDoubleOrNull() ?: 0.0
            val Y = tenureYears.toDoubleOrNull() ?: 0.0
            val emiRes = remember(P, R, Y) { FinanceEngine.calculateEmi(P, R, Y) }

            HorizontalDivider()
            Text("Monthly EMI", fontSize = 12.sp, color = Color.Gray)
            Text("$" + String.format(Locale.US, "%,.2f", emiRes.emi), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = accentColor)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Total Interest: $" + String.format(Locale.US, "%,.2f", emiRes.totalInterest), fontSize = 13.sp)
              Text("Total Payment: $" + String.format(Locale.US, "%,.2f", emiRes.totalPayment), fontSize = 13.sp)
            }
          }

          "interest" -> {
            var principal by remember { mutableStateOf("10000") }
            var rate by remember { mutableStateOf("7.5") }
            var timeYears by remember { mutableStateOf("3") }
            var compoundFreq by remember { mutableStateOf(4) } // 1, 2, 4, 12

            OutlinedTextField(value = principal, onValueChange = { principal = it }, label = { Text("Principal Amount ($)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = rate, onValueChange = { rate = it }, label = { Text("Annual Rate (%)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = timeYears, onValueChange = { timeYears = it }, label = { Text("Time (Years)") }, modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              listOf(1 to "Annually", 4 to "Quarterly", 12 to "Monthly").forEach { (f, lbl) ->
                FilterChip(
                  selected = compoundFreq == f,
                  onClick = { compoundFreq = f },
                  label = { Text(lbl, fontSize = 11.sp) }
                )
              }
            }

            val p = principal.toDoubleOrNull() ?: 0.0
            val r = rate.toDoubleOrNull() ?: 0.0
            val t = timeYears.toDoubleOrNull() ?: 0.0
            val res = FinanceEngine.calculateInterest(p, r, t, compoundFreq)

            HorizontalDivider()
            Text("Compound Total Amount", fontSize = 12.sp, color = Color.Gray)
            Text("$" + String.format(Locale.US, "%,.2f", res.compoundTotal), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = accentColor)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Simple Interest: $" + String.format(Locale.US, "%,.2f", res.simpleInterest), fontSize = 13.sp)
              Text("Compound Gain: +$" + String.format(Locale.US, "%,.2f", res.compoundAdvantage), fontSize = 13.sp, color = Color(0xFF10B981))
            }
          }

          "gst" -> {
            var gstAmount by remember { mutableStateOf("1000") }
            var gstRate by remember { mutableStateOf("18") }
            var isExclusive by remember { mutableStateOf(true) }

            OutlinedTextField(value = gstAmount, onValueChange = { gstAmount = it }, label = { Text("Amount ($)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = gstRate, onValueChange = { gstRate = it }, label = { Text("GST Rate (%)") }, modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              FilterChip(
                selected = isExclusive,
                onClick = { isExclusive = true },
                label = { Text("Add GST (Exclusive)") }
              )
              FilterChip(
                selected = !isExclusive,
                onClick = { isExclusive = false },
                label = { Text("Remove GST (Inclusive)") }
              )
            }

            val res = FinanceEngine.calculateGst(gstAmount.toDoubleOrNull() ?: 0.0, gstRate.toDoubleOrNull() ?: 0.0, isExclusive)
            HorizontalDivider()
            Text("Final Total", fontSize = 12.sp, color = Color.Gray)
            Text("$" + String.format(Locale.US, "%,.2f", res.gross), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = accentColor)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Net: $" + String.format(Locale.US, "%,.2f", res.net), fontSize = 13.sp)
              Text("Tax: $" + String.format(Locale.US, "%,.2f", res.tax) + " (CGST/SGST: $" + String.format(Locale.US, "%,.2f", res.cgst) + " each)", fontSize = 13.sp)
            }
          }

          "discount" -> {
            var origPrice by remember { mutableStateOf("120") }
            var discountPct by remember { mutableStateOf("25") }
            var couponPct by remember { mutableStateOf("5") }

            OutlinedTextField(value = origPrice, onValueChange = { origPrice = it }, label = { Text("Original Price ($)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = discountPct, onValueChange = { discountPct = it }, label = { Text("Discount (%)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = couponPct, onValueChange = { couponPct = it }, label = { Text("Extra Coupon (%)") }, modifier = Modifier.fillMaxWidth())

            val res = FinanceEngine.calculateDiscount(origPrice.toDoubleOrNull() ?: 0.0, discountPct.toDoubleOrNull() ?: 0.0, couponPct.toDoubleOrNull() ?: 0.0)
            HorizontalDivider()
            Text("Final Discounted Price", fontSize = 12.sp, color = Color.Gray)
            Text("$" + String.format(Locale.US, "%,.2f", res.finalPrice), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
            Text("Total Savings: $" + String.format(Locale.US, "%,.2f", res.totalSavings) + " (" + String.format(Locale.US, "%.1f", res.effectivePct) + "%)", fontSize = 13.sp)
          }

          "profit" -> {
            var cpStr by remember { mutableStateOf("80") }
            var spStr by remember { mutableStateOf("115") }

            OutlinedTextField(value = cpStr, onValueChange = { cpStr = it }, label = { Text("Cost Price ($)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = spStr, onValueChange = { spStr = it }, label = { Text("Selling Price ($)") }, modifier = Modifier.fillMaxWidth())

            val res = FinanceEngine.calculateProfitLoss(cpStr.toDoubleOrNull() ?: 0.0, spStr.toDoubleOrNull() ?: 0.0)
            HorizontalDivider()
            Text(if (res.isProfit) "Net Profit" else "Net Loss", fontSize = 12.sp, color = Color.Gray)
            Text(
              (if (res.isProfit) "+$" else "-$") + String.format(Locale.US, "%,.2f", kotlin.math.abs(res.diff)),
              fontSize = 28.sp,
              fontWeight = FontWeight.Bold,
              color = if (res.isProfit) Color(0xFF10B981) else Color(0xFFEF4444)
            )
            Text("Percentage: " + String.format(Locale.US, "%.2f", res.pct) + "% | Margin: " + String.format(Locale.US, "%.2f", res.margin) + "%", fontSize = 13.sp)
          }

          "sip" -> {
            var monthlySip by remember { mutableStateOf("500") }
            var sipRate by remember { mutableStateOf("12") }
            var sipYears by remember { mutableStateOf("15") }

            OutlinedTextField(value = monthlySip, onValueChange = { monthlySip = it }, label = { Text("Monthly Investment ($)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sipRate, onValueChange = { sipRate = it }, label = { Text("Expected Return (%)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = sipYears, onValueChange = { sipYears = it }, label = { Text("Years") }, modifier = Modifier.fillMaxWidth())

            val sipRes = FinanceEngine.calculateSip(monthlySip.toDoubleOrNull() ?: 0.0, sipRate.toDoubleOrNull() ?: 0.0, sipYears.toDoubleOrNull() ?: 0.0)

            HorizontalDivider()
            Text("Future Wealth Value", fontSize = 12.sp, color = Color.Gray)
            Text("$" + String.format(Locale.US, "%,.0f", sipRes.futureValue), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
            Text("Invested: $" + String.format(Locale.US, "%,.0f", sipRes.invested) + "  |  Gain: $" + String.format(Locale.US, "%,.0f", sipRes.gain), fontSize = 13.sp)
          }
        }
      }
    }
  }
}

@Composable
fun HistoryScreen(
  historyList: List<HistoryEntry>,
  surfaceColor: Color,
  textColor: Color,
  accentColor: Color,
  onReuse: (HistoryEntry) -> Unit,
  onCopy: (String) -> Unit,
  onClear: () -> Unit
) {
  Column(modifier = Modifier.fillMaxSize()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text("${historyList.size} calculations", fontWeight = FontWeight.Bold, color = textColor)
      TextButton(onClick = onClear) {
        Text("Clear All", color = Color(0xFFEF4444))
      }
    }

    if (historyList.isEmpty()) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("No calculations yet.", color = Color.Gray)
      }
    } else {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(historyList) { _, entry ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onReuse(entry) },
            colors = CardDefaults.cardColors(containerColor = surfaceColor)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(entry.timestamp, fontSize = 11.sp, color = Color.Gray)
                IconButton(onClick = { onCopy(entry.result) }, modifier = Modifier.size(20.dp)) {
                  Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy", tint = Color.Gray, modifier = Modifier.size(14.dp))
                }
              }
              Text(entry.expression, fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = textColor.copy(alpha = 0.8f))
              Text("= " + entry.result, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = accentColor, modifier = Modifier.align(Alignment.End))
            }
          }
        }
      }
    }
  }
}
