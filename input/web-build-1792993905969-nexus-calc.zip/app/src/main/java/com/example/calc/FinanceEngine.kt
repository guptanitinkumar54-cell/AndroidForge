package com.example.calc

import kotlin.math.abs
import kotlin.math.pow

object FinanceEngine {

  data class EmiResult(
    val emi: Double,
    val principal: Double,
    val totalInterest: Double,
    val totalPayment: Double,
    val principalPercent: Int,
    val interestPercent: Int
  )

  fun calculateEmi(principal: Double, annualRate: Double, tenureYears: Double): EmiResult {
    val r = (annualRate / 12.0) / 100.0
    val n = tenureYears * 12.0

    val emi = if (r > 0 && n > 0) {
      (principal * r * (1 + r).pow(n)) / ((1 + r).pow(n) - 1)
    } else if (n > 0) {
      principal / n
    } else 0.0

    val totalPayment = emi * n
    val totalInterest = (totalPayment - principal).coerceAtLeast(0.0)
    val pPct = if (totalPayment > 0) ((principal / totalPayment) * 100).toInt() else 100
    val iPct = 100 - pPct

    return EmiResult(emi, principal, totalInterest, totalPayment, pPct, iPct)
  }

  data class InterestResult(
    val simpleInterest: Double,
    val compoundTotal: Double,
    val compoundInterest: Double,
    val compoundAdvantage: Double
  )

  fun calculateInterest(principal: Double, annualRate: Double, years: Double, compoundFreq: Int): InterestResult {
    val simpleInt = (principal * annualRate * years) / 100.0
    val n = compoundFreq.toDouble().coerceAtLeast(1.0)
    val compoundTotal = principal * (1.0 + (annualRate / (100.0 * n))).pow(n * years)
    val compoundInt = compoundTotal - principal
    val diff = (compoundInt - simpleInt).coerceAtLeast(0.0)

    return InterestResult(simpleInt, compoundTotal, compoundInt, diff)
  }

  data class GstResult(
    val net: Double,
    val tax: Double,
    val gross: Double,
    val cgst: Double,
    val sgst: Double
  )

  fun calculateGst(amount: Double, rate: Double, isExclusive: Boolean): GstResult {
    val net: Double
    val tax: Double
    val gross: Double

    if (isExclusive) {
      net = amount
      tax = (amount * rate) / 100.0
      gross = net + tax
    } else {
      gross = amount
      net = (amount * 100.0) / (100.0 + rate)
      tax = gross - net
    }

    return GstResult(net, tax, gross, tax / 2.0, tax / 2.0)
  }

  data class SipResult(
    val futureValue: Double,
    val invested: Double,
    val gain: Double,
    val investedPercent: Int,
    val gainPercent: Int
  )

  fun calculateSip(monthly: Double, annualRate: Double, years: Double): SipResult {
    val i = (annualRate / 12.0) / 100.0
    val n = years * 12.0

    val futureVal = if (i > 0 && n > 0) {
      monthly * (((1.0 + i).pow(n) - 1.0) / i) * (1.0 + i)
    } else {
      monthly * n
    }

    val invested = monthly * n
    val gain = (futureVal - invested).coerceAtLeast(0.0)
    val invPct = if (futureVal > 0) ((invested / futureVal) * 100).toInt() else 100
    val gainPct = 100 - invPct

    return SipResult(futureVal, invested, gain, invPct, gainPct)
  }

  data class DiscountResult(
    val finalPrice: Double,
    val totalSavings: Double,
    val effectivePct: Double
  )

  fun calculateDiscount(original: Double, discountPct: Double, couponPct: Double): DiscountResult {
    val step1 = original * (1.0 - (discountPct / 100.0))
    val finalPrice = step1 * (1.0 - (couponPct / 100.0))
    val savings = (original - finalPrice).coerceAtLeast(0.0)
    val effective = if (original > 0) (savings / original) * 100.0 else 0.0
    return DiscountResult(finalPrice, savings, effective)
  }

  data class ProfitLossResult(
    val diff: Double,
    val pct: Double,
    val margin: Double,
    val isProfit: Boolean
  )

  fun calculateProfitLoss(cp: Double, sp: Double): ProfitLossResult {
    val diff = sp - cp
    val pct = if (cp > 0) (diff / cp) * 100.0 else 0.0
    val margin = if (sp > 0) (diff / sp) * 100.0 else 0.0
    return ProfitLossResult(diff, pct, margin, diff >= 0)
  }

  data class PercentChangeResult(
    val diff: Double,
    val pct: Double,
    val isIncrease: Boolean
  )

  fun calculatePercentageChange(initVal: Double, finalVal: Double): PercentChangeResult {
    val diff = finalVal - initVal
    val pct = if (initVal != 0.0) (diff / abs(initVal)) * 100.0 else 0.0
    return PercentChangeResult(diff, pct, diff >= 0)
  }
}
