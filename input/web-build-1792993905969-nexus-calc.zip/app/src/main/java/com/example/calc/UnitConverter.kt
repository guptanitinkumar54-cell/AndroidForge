package com.example.calc

data class UnitDef(val id: String, val name: String, val factor: Double = 1.0)

data class UnitCategory(
  val id: String,
  val name: String,
  val units: List<UnitDef>,
  val defaultFrom: String,
  val defaultTo: String
)

object UnitConverter {

  val categories = listOf(
    UnitCategory(
      id = "length",
      name = "Length",
      units = listOf(
        UnitDef("mm", "Millimeters (mm)", 0.001),
        UnitDef("cm", "Centimeters (cm)", 0.01),
        UnitDef("m", "Meters (m)", 1.0),
        UnitDef("km", "Kilometers (km)", 1000.0),
        UnitDef("in", "Inches (in)", 0.0254),
        UnitDef("ft", "Feet (ft)", 0.3048),
        UnitDef("yd", "Yards (yd)", 0.9144),
        UnitDef("mi", "Miles (mi)", 1609.344)
      ),
      defaultFrom = "m",
      defaultTo = "cm"
    ),
    UnitCategory(
      id = "weight",
      name = "Weight",
      units = listOf(
        UnitDef("mg", "Milligrams (mg)", 0.000001),
        UnitDef("g", "Grams (g)", 0.001),
        UnitDef("kg", "Kilograms (kg)", 1.0),
        UnitDef("t", "Tonnes (t)", 1000.0),
        UnitDef("oz", "Ounces (oz)", 0.0283495),
        UnitDef("lb", "Pounds (lb)", 0.45359237)
      ),
      defaultFrom = "kg",
      defaultTo = "lb"
    ),
    UnitCategory(
      id = "temp",
      name = "Temperature",
      units = listOf(
        UnitDef("c", "Celsius (°C)"),
        UnitDef("f", "Fahrenheit (°F)"),
        UnitDef("k", "Kelvin (K)")
      ),
      defaultFrom = "c",
      defaultTo = "f"
    ),
    UnitCategory(
      id = "speed",
      name = "Speed",
      units = listOf(
        UnitDef("mps", "Meters / sec (m/s)", 1.0),
        UnitDef("kmh", "km / hour (km/h)", 0.277778),
        UnitDef("mph", "Miles / hour (mph)", 0.44704),
        UnitDef("knot", "Knots", 0.514444)
      ),
      defaultFrom = "kmh",
      defaultTo = "mph"
    ),
    UnitCategory(
      id = "area",
      name = "Area",
      units = listOf(
        UnitDef("sq_m", "Square Meters (m²)", 1.0),
        UnitDef("sq_km", "Square km (km²)", 1000000.0),
        UnitDef("sq_ft", "Square Feet (ft²)", 0.092903),
        UnitDef("acre", "Acres", 4046.86),
        UnitDef("hectare", "Hectares", 10000.0)
      ),
      defaultFrom = "sq_m",
      defaultTo = "sq_ft"
    ),
    UnitCategory(
      id = "volume",
      name = "Volume",
      units = listOf(
        UnitDef("ml", "Milliliters (mL)", 0.001),
        UnitDef("l", "Liters (L)", 1.0),
        UnitDef("m3", "Cubic Meters (m³)", 1000.0),
        UnitDef("floz", "Fluid Ounces (fl oz)", 0.0295735),
        UnitDef("gal", "Gallons (US gal)", 3.78541)
      ),
      defaultFrom = "l",
      defaultTo = "gal"
    ),
    UnitCategory(
      id = "time",
      name = "Time",
      units = listOf(
        UnitDef("ms", "Milliseconds (ms)", 0.001),
        UnitDef("s", "Seconds (s)", 1.0),
        UnitDef("min", "Minutes (min)", 60.0),
        UnitDef("hr", "Hours (hr)", 3600.0),
        UnitDef("day", "Days", 86400.0),
        UnitDef("wk", "Weeks", 604800.0)
      ),
      defaultFrom = "hr",
      defaultTo = "min"
    ),
    UnitCategory(
      id = "digital",
      name = "Digital",
      units = listOf(
        UnitDef("b", "Bytes (B)", 1.0),
        UnitDef("kb", "Kilobytes (KB)", 1024.0),
        UnitDef("mb", "Megabytes (MB)", 1048576.0),
        UnitDef("gb", "Gigabytes (GB)", 1073741824.0),
        UnitDef("tb", "Terabytes (TB)", 1099511627776.0)
      ),
      defaultFrom = "gb",
      defaultTo = "mb"
    )
  )

  fun convert(categoryId: String, value: Double, fromUnitId: String, toUnitId: String): Double {
    if (categoryId == "temp") {
      val celsius = when (fromUnitId) {
        "c" -> value
        "f" -> (value - 32.0) * 5.0 / 9.0
        "k" -> value - 273.15
        else -> value
      }
      return when (toUnitId) {
        "c" -> celsius
        "f" -> (celsius * 9.0 / 5.0) + 32.0
        "k" -> celsius + 273.15
        else -> celsius
      }
    }

    val cat = categories.find { it.id == categoryId } ?: return value
    val from = cat.units.find { it.id == fromUnitId } ?: return value
    val to = cat.units.find { it.id == toUnitId } ?: return value

    val baseValue = value * from.factor
    return baseValue / to.factor
  }
}
