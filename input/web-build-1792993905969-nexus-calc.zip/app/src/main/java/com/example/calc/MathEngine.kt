package com.example.calc

import java.util.Stack
import kotlin.math.PI
import kotlin.math.E
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.cbrt
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Safe Mathematical Expression Evaluator for NEXUS CALC.
 * Uses custom Tokenizer, Shunting-Yard infix-to-RPN algorithm, and RPN Evaluator.
 */
object MathEngine {

  private data class Token(val type: TokenType, val value: String, val numValue: Double = 0.0)

  private enum class TokenType {
    NUMBER, OPERATOR, FUNCTION, UNARY_MINUS, POSTFIX, PAREN_OPEN, PAREN_CLOSE
  }

  private data class OpDef(val prec: Int, val isRightAssoc: Boolean)

  private val OPERATORS = mapOf(
    "+" to OpDef(1, false),
    "-" to OpDef(1, false),
    "*" to OpDef(2, false),
    "/" to OpDef(2, false),
    "%" to OpDef(2, false),
    "neg" to OpDef(3, true),
    "^" to OpDef(4, true),
    "!" to OpDef(5, false)
  )

  fun evaluate(expression: String, isDegreeMode: Boolean = true): Double {
    if (expression.isBlank()) return 0.0

    // Auto-balance unclosed open parentheses for user convenience
    var balanced = expression
    val openCount = balanced.count { it == '(' }
    val closeCount = balanced.count { it == ')' }
    if (openCount > closeCount) {
      balanced += ")".repeat(openCount - closeCount)
    }

    val tokens = tokenize(balanced)
    val rpn = shuntingYard(tokens)
    return evaluateRPN(rpn, isDegreeMode)
  }

  private fun tokenize(input: String): List<Token> {
    val clean = input
      .replace("×", "*")
      .replace("÷", "/")
      .replace("−", "-")
      .replace("π", "pi")
      .replace("mod", "%", ignoreCase = true)
      .replace(",", "")
      .trim()

    val rawTokens = mutableListOf<Token>()
    var i = 0

    while (i < clean.length) {
      val c = clean[i]
      if (c.isWhitespace()) {
        i++
        continue
      }

      if (c.isDigit() || c == '.') {
        val sb = StringBuilder()
        var hasDot = false
        while (i < clean.length && (clean[i].isDigit() || clean[i] == '.')) {
          if (clean[i] == '.') {
            if (hasDot) break
            hasDot = true
          }
          sb.append(clean[i])
          i++
        }
        val num = sb.toString().toDoubleOrNull() ?: throw IllegalArgumentException("Invalid number")
        rawTokens.add(Token(TokenType.NUMBER, sb.toString(), num))
        continue
      }

      if (c.isLetter()) {
        val sb = StringBuilder()
        while (i < clean.length && clean[i].isLetter()) {
          sb.append(clean[i].lowercaseChar())
          i++
        }
        val str = sb.toString()
        when (str) {
          "pi" -> rawTokens.add(Token(TokenType.NUMBER, "pi", PI))
          "e" -> rawTokens.add(Token(TokenType.NUMBER, "e", E))
          else -> rawTokens.add(Token(TokenType.FUNCTION, str))
        }
        continue
      }

      when (c) {
        '+', '-', '*', '/', '%', '^', '!' -> {
          var isUnary = false
          if (c == '-') {
            val prev = rawTokens.lastOrNull()
            if (prev == null || prev.type == TokenType.OPERATOR || prev.type == TokenType.PAREN_OPEN || prev.type == TokenType.UNARY_MINUS) {
              isUnary = true
            }
          }

          if (isUnary) {
            rawTokens.add(Token(TokenType.UNARY_MINUS, "neg"))
          } else if (c == '!') {
            rawTokens.add(Token(TokenType.POSTFIX, "!"))
          } else {
            rawTokens.add(Token(TokenType.OPERATOR, c.toString()))
          }
          i++
        }
        '(' -> {
          rawTokens.add(Token(TokenType.PAREN_OPEN, "("))
          i++
        }
        ')' -> {
          rawTokens.add(Token(TokenType.PAREN_CLOSE, ")"))
          i++
        }
        else -> throw IllegalArgumentException("Unexpected character '$c'")
      }
    }

    // Insert implicit multiplications: e.g., 2(3) -> 2*(3), (2)(3) -> (2)*(3), 2pi -> 2*pi
    val expanded = mutableListOf<Token>()
    for (k in rawTokens.indices) {
      val cur = rawTokens[k]
      val prev = rawTokens.getOrNull(k - 1)
      if (prev != null) {
        val prevIsVal = prev.type == TokenType.NUMBER || prev.type == TokenType.PAREN_CLOSE || prev.type == TokenType.POSTFIX
        val curIsVal = cur.type == TokenType.NUMBER || cur.type == TokenType.PAREN_OPEN || cur.type == TokenType.FUNCTION
        if (prevIsVal && curIsVal) {
          expanded.add(Token(TokenType.OPERATOR, "*"))
        }
      }
      expanded.add(cur)
    }

    return expanded
  }

  private fun shuntingYard(tokens: List<Token>): List<Token> {
    val output = mutableListOf<Token>()
    val stack = Stack<Token>()

    for (token in tokens) {
      when (token.type) {
        TokenType.NUMBER -> output.add(token)
        TokenType.FUNCTION -> stack.push(token)
        TokenType.POSTFIX -> output.add(token)
        TokenType.OPERATOR, TokenType.UNARY_MINUS -> {
          val op1 = token.value
          val def1 = OPERATORS[op1] ?: OpDef(0, false)
          while (!stack.isEmpty()) {
            val top = stack.peek()
            if (top.type == TokenType.FUNCTION) {
              output.add(stack.pop())
              continue
            }
            if (top.type == TokenType.OPERATOR || top.type == TokenType.UNARY_MINUS) {
              val op2 = top.value
              val def2 = OPERATORS[op2] ?: OpDef(0, false)
              if ((!def1.isRightAssoc && def1.prec <= def2.prec) || (def1.isRightAssoc && def1.prec < def2.prec)) {
                output.add(stack.pop())
                continue
              }
            }
            break
          }
          stack.push(token)
        }
        TokenType.PAREN_OPEN -> stack.push(token)
        TokenType.PAREN_CLOSE -> {
          var found = false
          while (!stack.isEmpty()) {
            val top = stack.pop()
            if (top.type == TokenType.PAREN_OPEN) {
              found = true
              break
            }
            output.add(top)
          }
          if (!found) throw IllegalArgumentException("Mismatched parentheses")
          if (!stack.isEmpty() && stack.peek().type == TokenType.FUNCTION) {
            output.add(stack.pop())
          }
        }
      }
    }

    while (!stack.isEmpty()) {
      val top = stack.pop()
      if (top.type == TokenType.PAREN_OPEN || top.type == TokenType.PAREN_CLOSE) {
        throw IllegalArgumentException("Mismatched parentheses")
      }
      output.add(top)
    }

    return output
  }

  private fun evaluateRPN(rpn: List<Token>, isDegreeMode: Boolean): Double {
    val stack = Stack<Double>()

    fun toRad(deg: Double) = deg * PI / 180.0
    fun toDeg(rad: Double) = rad * 180.0 / PI

    for (token in rpn) {
      when (token.type) {
        TokenType.NUMBER -> stack.push(token.numValue)
        TokenType.UNARY_MINUS -> {
          if (stack.isEmpty()) throw IllegalArgumentException("Invalid syntax")
          stack.push(-stack.pop())
        }
        TokenType.POSTFIX -> {
          if (token.value == "!") {
            if (stack.isEmpty()) throw IllegalArgumentException("Invalid syntax")
            val n = stack.pop()
            if (n < 0 || n != kotlin.math.floor(n)) throw IllegalArgumentException("Factorial requires non-negative integer")
            if (n > 170) stack.push(Double.POSITIVE_INFINITY)
            else {
              var f = 1.0
              for (k in 2..n.toInt()) f *= k
              stack.push(f)
            }
          }
        }
        TokenType.OPERATOR -> {
          if (stack.size < 2) throw IllegalArgumentException("Invalid syntax")
          val b = stack.pop()
          val a = stack.pop()
          val res = when (token.value) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> {
              if (b == 0.0) throw ArithmeticException("Cannot divide by zero")
              a / b
            }
            "%" -> {
              if (b == 0.0) throw ArithmeticException("Cannot divide by zero")
              a % b
            }
            "^" -> a.pow(b)
            else -> throw IllegalArgumentException("Unknown operator: ${token.value}")
          }
          stack.push(res)
        }
        TokenType.FUNCTION -> {
          if (stack.isEmpty()) throw IllegalArgumentException("Invalid function call")
          val arg = stack.pop()
          val res = when (token.value) {
            "sin" -> {
              val v = sin(if (isDegreeMode) toRad(arg) else arg)
              if (abs(v) < 1e-15) 0.0 else v
            }
            "cos" -> {
              val v = cos(if (isDegreeMode) toRad(arg) else arg)
              if (abs(v) < 1e-15) 0.0 else v
            }
            "tan" -> {
              val rad = if (isDegreeMode) toRad(arg) else arg
              if (abs(cos(rad)) < 1e-15) throw ArithmeticException("Undefined (tan 90°)")
              tan(rad)
            }
            "asin" -> {
              if (arg < -1.0 || arg > 1.0) throw ArithmeticException("asin domain [-1, 1]")
              val v = asin(arg)
              if (isDegreeMode) toDeg(v) else v
            }
            "acos" -> {
              if (arg < -1.0 || arg > 1.0) throw ArithmeticException("acos domain [-1, 1]")
              val v = acos(arg)
              if (isDegreeMode) toDeg(v) else v
            }
            "atan" -> {
              val v = atan(arg)
              if (isDegreeMode) toDeg(v) else v
            }
            "ln" -> {
              if (arg <= 0.0) throw ArithmeticException("ln domain x > 0")
              ln(arg)
            }
            "log" -> {
              if (arg <= 0.0) throw ArithmeticException("log domain x > 0")
              log10(arg)
            }
            "sqrt" -> {
              if (arg < 0.0) throw ArithmeticException("Cannot take √ of negative")
              sqrt(arg)
            }
            "cbrt" -> cbrt(arg)
            "abs" -> abs(arg)
            else -> throw IllegalArgumentException("Unknown function: ${token.value}")
          }
          stack.push(res)
        }
        else -> {}
      }
    }

    if (stack.size != 1) throw IllegalArgumentException("Malformed expression")
    return stack.pop()
  }

  fun formatNumber(num: Double, precision: String): String {
    if (num.isNaN()) return "Error"
    if (num.isInfinite()) return if (num > 0) "Infinity" else "-Infinity"

    return try {
      when (precision) {
        "2" -> String.format(java.util.Locale.US, "%,.2f", num)
        "4" -> String.format(java.util.Locale.US, "%,.4f", num)
        "6" -> String.format(java.util.Locale.US, "%,.6f", num)
        "8" -> String.format(java.util.Locale.US, "%,.8f", num)
        else -> {
          // Auto precision: if integer, show integer format with commas
          if (num == kotlin.math.floor(num) && abs(num) < 1e12) {
            String.format(java.util.Locale.US, "%,d", num.toLong())
          } else {
            // Trim unnecessary trailing zeros
            val s = String.format(java.util.Locale.US, "%,.10f", num)
            val parts = s.split(".")
            if (parts.size == 2) {
              val trimmedDec = parts[1].trimEnd('0')
              if (trimmedDec.isEmpty()) parts[0] else "${parts[0]}.$trimmedDec"
            } else s
          }
        }
      }
    } catch (_: Exception) {
      num.toString()
    }
  }
}
