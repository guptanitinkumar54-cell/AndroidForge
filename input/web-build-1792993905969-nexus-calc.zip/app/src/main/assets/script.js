/**
 * NEXUS CALC - Professional Advanced Calculator Engine
 * Pure Vanilla JavaScript with Safe Expression Parser (Shunting-Yard / RPN)
 */

(function () {
  'use strict';

  /* ==========================================================================
     1. State Management & Storage
     ========================================================================== */
  const STATE = {
    theme: localStorage.getItem('nexus_calc_theme') || 'dark',
    soundEnabled: localStorage.getItem('nexus_calc_sound') !== 'false',
    precision: localStorage.getItem('nexus_calc_precision') || 'auto',
    angleMode: localStorage.getItem('nexus_calc_angle') || 'DEG', // 'DEG' or 'RAD'
    isSecondFn: false,
    memory: parseFloat(localStorage.getItem('nexus_calc_memory') || '0'),
    activeTab: 'standard',
    activeFinanceTab: 'emi',

    // Calculator Core State
    expression: '',        // Expression string
    result: '0',           // Current evaluated or displayed result
    isEvaluated: false,    // True after '=' is pressed
    hasError: false,

    // History
    history: []
  };

  // Load History from localStorage safely
  try {
    const saved = localStorage.getItem('nexus_calc_history');
    if (saved) {
      STATE.history = JSON.parse(saved);
    }
  } catch (e) {
    console.error('Failed to parse history:', e);
    STATE.history = [];
  }

  /* ==========================================================================
     2. Web Audio Synthesizer (Zero External Audio Files)
     ========================================================================== */
  let audioCtx = null;
  function getAudioContext() {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function playSound(type) {
    if (!STATE.soundEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'click') {
        // Soft subtle mechanical click
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
        osc.start(now);
        osc.stop(now + 0.04);
      } else if (type === 'operator') {
        // Medium pitch soft blip
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(540, now);
        osc.frequency.exponentialRampToValueAtTime(420, now + 0.06);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
        osc.start(now);
        osc.stop(now + 0.06);
      } else if (type === 'equals') {
        // Pleasant success chime
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.06); // E5
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        osc.start(now);
        osc.stop(now + 0.18);
      } else if (type === 'error') {
        // Low error buzz
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.linearRampToValueAtTime(110, now + 0.15);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.15);
      }
    } catch (e) {
      // Audio playback might be restricted before user gesture
    }

    // Trigger Android bridge haptics if available or browser vibration
    triggerHaptic(type === 'error' ? 50 : 15);
  }

  function triggerHaptic(durationMs) {
    if (window.AndroidBridge && typeof window.AndroidBridge.vibrate === 'function') {
      try {
        window.AndroidBridge.vibrate(durationMs);
      } catch (e) {}
    } else if (navigator.vibrate) {
      try {
        navigator.vibrate(durationMs);
      } catch (e) {}
    }
  }

  /* ==========================================================================
     3. Safe Math Parser (Shunting-Yard & RPN Evaluator)
     No eval(), no Function() constructor.
     ========================================================================== */

  // Factorial with caching and domain check
  function factorial(n) {
    if (n < 0 || !Number.isInteger(n)) throw new Error('Factorial invalid for negative/non-integer');
    if (n > 170) return Infinity;
    if (n === 0 || n === 1) return 1;
    let res = 1;
    for (let i = 2; i <= n; i++) res *= i;
    return res;
  }

  // Tokenizer
  function tokenize(input) {
    // Standardize input string
    let str = input
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/π/g, 'pi')
      .replace(/MOD/gi, '%')
      .replace(/,/g, '');

    const tokens = [];
    let i = 0;

    const isDigit = ch => (ch >= '0' && ch <= '9') || ch === '.';
    const isAlpha = ch => (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z');

    while (i < str.length) {
      const ch = str[i];

      if (/\s/.test(ch)) {
        i++;
        continue;
      }

      // Check for numbers
      if (isDigit(ch)) {
        let numStr = '';
        let hasDot = false;
        while (i < str.length && isDigit(str[i])) {
          if (str[i] === '.') {
            if (hasDot) break;
            hasDot = true;
          }
          numStr += str[i];
          i++;
        }
        tokens.push({ type: 'NUMBER', value: parseFloat(numStr) });
        continue;
      }

      // Check for identifiers (functions, constants)
      if (isAlpha(ch)) {
        let ident = '';
        while (i < str.length && isAlpha(str[i])) {
          ident += str[i].toLowerCase();
          i++;
        }

        if (ident === 'pi') {
          tokens.push({ type: 'NUMBER', value: Math.PI });
        } else if (ident === 'e') {
          tokens.push({ type: 'NUMBER', value: Math.E });
        } else {
          // Functions: sin, cos, tan, asin, acos, atan, ln, log, sqrt, cbrt, abs
          tokens.push({ type: 'FUNCTION', value: ident });
        }
        continue;
      }

      // Check operators and punctuation
      if (ch === '+' || ch === '-' || ch === '*' || ch === '/' || ch === '%' || ch === '^' || ch === '!') {
        // Detect unary minus
        let isUnaryMinus = false;
        if (ch === '-') {
          const prevToken = tokens[tokens.length - 1];
          if (!prevToken || prevToken.type === 'OPERATOR' || (prevToken.type === 'PAREN' && prevToken.value === '(')) {
            isUnaryMinus = true;
          }
        }

        if (isUnaryMinus) {
          tokens.push({ type: 'UNARY_MINUS', value: 'neg' });
        } else if (ch === '!') {
          tokens.push({ type: 'POSTFIX', value: '!' });
        } else {
          tokens.push({ type: 'OPERATOR', value: ch });
        }
        i++;
        continue;
      }

      if (ch === '(' || ch === ')') {
        tokens.push({ type: 'PAREN', value: ch });
        i++;
        continue;
      }

      throw new Error(`Unexpected character: "${ch}"`);
    }

    // Insert implicit multiplications: e.g. 2(3) -> 2*(3), (2+3)(4) -> (2+3)*(4), 2pi -> 2*pi
    const expanded = [];
    for (let k = 0; k < tokens.length; k++) {
      const cur = tokens[k];
      const prev = tokens[k - 1];

      if (prev) {
        const prevIsVal = prev.type === 'NUMBER' || (prev.type === 'PAREN' && prev.value === ')') || prev.type === 'POSTFIX';
        const curIsVal = cur.type === 'NUMBER' || (cur.type === 'PAREN' && cur.value === '(') || cur.type === 'FUNCTION';

        if (prevIsVal && curIsVal) {
          expanded.push({ type: 'OPERATOR', value: '*' });
        }
      }
      expanded.push(cur);
    }

    return expanded;
  }

  // Operator precedence & associativity
  const OPS = {
    '+': { prec: 1, assoc: 'L' },
    '-': { prec: 1, assoc: 'L' },
    '*': { prec: 2, assoc: 'L' },
    '/': { prec: 2, assoc: 'L' },
    '%': { prec: 2, assoc: 'L' },
    '^': { prec: 4, assoc: 'R' },
    'neg': { prec: 5, assoc: 'R' },
    '!': { prec: 6, assoc: 'L' }
  };

  // Shunting-Yard: Infix tokens to RPN
  function shuntingYard(tokens) {
    const output = [];
    const opStack = [];

    for (let token of tokens) {
      if (token.type === 'NUMBER') {
        output.push(token);
      } else if (token.type === 'FUNCTION') {
        opStack.push(token);
      } else if (token.type === 'POSTFIX') {
        output.push(token);
      } else if (token.type === 'OPERATOR' || token.type === 'UNARY_MINUS') {
        const op1 = token.value;
        const o1 = OPS[op1] || { prec: 0, assoc: 'L' };

        while (opStack.length > 0) {
          const top = opStack[opStack.length - 1];
          if (top.type === 'FUNCTION') {
            output.push(opStack.pop());
            continue;
          }
          if (top.type === 'OPERATOR' || top.type === 'UNARY_MINUS') {
            const op2 = top.value;
            const o2 = OPS[op2] || { prec: 0, assoc: 'L' };
            if ((o1.assoc === 'L' && o1.prec <= o2.prec) || (o1.assoc === 'R' && o1.prec < o2.prec)) {
              output.push(opStack.pop());
              continue;
            }
          }
          break;
        }
        opStack.push(token);
      } else if (token.type === 'PAREN' && token.value === '(') {
        opStack.push(token);
      } else if (token.type === 'PAREN' && token.value === ')') {
        let foundOpen = false;
        while (opStack.length > 0) {
          const top = opStack.pop();
          if (top.type === 'PAREN' && top.value === '(') {
            foundOpen = true;
            break;
          }
          output.push(top);
        }
        if (!foundOpen) {
          throw new Error('Mismatched parentheses');
        }
        if (opStack.length > 0 && opStack[opStack.length - 1].type === 'FUNCTION') {
          output.push(opStack.pop());
        }
      }
    }

    while (opStack.length > 0) {
      const top = opStack.pop();
      if (top.type === 'PAREN') {
        throw new Error('Mismatched parentheses');
      }
      output.push(top);
    }

    return output;
  }

  // Evaluate RPN Queue
  function evaluateRPN(rpn, angleMode) {
    const stack = [];
    const toRadians = deg => (deg * Math.PI) / 180;
    const toDegrees = rad => (rad * 180) / Math.PI;

    for (let token of rpn) {
      if (token.type === 'NUMBER') {
        stack.push(token.value);
      } else if (token.type === 'UNARY_MINUS') {
        if (stack.length < 1) throw new Error('Invalid syntax');
        const a = stack.pop();
        stack.push(-a);
      } else if (token.type === 'POSTFIX' && token.value === '!') {
        if (stack.length < 1) throw new Error('Invalid syntax');
        const a = stack.pop();
        stack.push(factorial(a));
      } else if (token.type === 'OPERATOR') {
        if (stack.length < 2) throw new Error('Invalid syntax');
        const b = stack.pop();
        const a = stack.pop();
        let res = 0;

        switch (token.value) {
          case '+': res = a + b; break;
          case '-': res = a - b; break;
          case '*': res = a * b; break;
          case '/':
            if (b === 0) throw new Error('Cannot divide by zero');
            res = a / b;
            break;
          case '%':
            if (b === 0) throw new Error('Cannot divide by zero');
            res = a % b;
            break;
          case '^':
            res = Math.pow(a, b);
            break;
          default:
            throw new Error(`Unknown operator: ${token.value}`);
        }
        stack.push(res);
      } else if (token.type === 'FUNCTION') {
        if (stack.length < 1) throw new Error('Invalid function call');
        const arg = stack.pop();
        let val = 0;

        switch (token.value) {
          case 'sin':
            val = Math.sin(angleMode === 'DEG' ? toRadians(arg) : arg);
            // Fix floating point precision near zero
            if (Math.abs(val) < 1e-15) val = 0;
            break;
          case 'cos':
            val = Math.cos(angleMode === 'DEG' ? toRadians(arg) : arg);
            if (Math.abs(val) < 1e-15) val = 0;
            break;
          case 'tan': {
            const rad = angleMode === 'DEG' ? toRadians(arg) : arg;
            if (Math.abs(Math.cos(rad)) < 1e-15) throw new Error('Undefined (tan 90°)');
            val = Math.tan(rad);
            break;
          }
          case 'asin':
            if (arg < -1 || arg > 1) throw new Error('asin domain is [-1, 1]');
            val = Math.asin(arg);
            if (angleMode === 'DEG') val = toDegrees(val);
            break;
          case 'acos':
            if (arg < -1 || arg > 1) throw new Error('acos domain is [-1, 1]');
            val = Math.acos(arg);
            if (angleMode === 'DEG') val = toDegrees(val);
            break;
          case 'atan':
            val = Math.atan(arg);
            if (angleMode === 'DEG') val = toDegrees(val);
            break;
          case 'ln':
            if (arg <= 0) throw new Error('ln domain is x > 0');
            val = Math.log(arg);
            break;
          case 'log':
            if (arg <= 0) throw new Error('log domain is x > 0');
            val = Math.log10(arg);
            break;
          case 'sqrt':
            if (arg < 0) throw new Error('Cannot take √ of negative');
            val = Math.sqrt(arg);
            break;
          case 'cbrt':
            val = Math.cbrt(arg);
            break;
          case 'abs':
            val = Math.abs(arg);
            break;
          default:
            throw new Error(`Unknown function: ${token.value}`);
        }
        stack.push(val);
      }
    }

    if (stack.length !== 1) {
      throw new Error('Malformed expression');
    }

    const finalVal = stack[0];
    if (isNaN(finalVal)) throw new Error('Result is NaN');
    return finalVal;
  }

  // Public evaluation method with safe error handling
  function safeCalculate(expression, angleMode) {
    if (!expression || expression.trim() === '') return 0;
    const tokens = tokenize(expression);
    const rpn = shuntingYard(tokens);
    return evaluateRPN(rpn, angleMode);
  }

  // Format numbers for display with precision & thousands separator
  function formatNumber(num, precision) {
    if (typeof num !== 'number' || isNaN(num)) return 'Error';
    if (!isFinite(num)) return num > 0 ? 'Infinity' : '-Infinity';

    let rounded = num;
    if (precision !== 'auto') {
      const decimals = parseInt(precision, 10);
      rounded = Number(Math.round(num + 'e' + decimals) + 'e-' + decimals);
    } else {
      // Auto precision up to 10 decimal digits avoiding 0.0000000000000002
      rounded = Number(Math.round(num + 'e10') + 'e-10');
    }

    // Split integer and decimal parts
    const parts = rounded.toString().split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
  }

  /* ==========================================================================
     4. UI Controller & Calculator Interactions
     ========================================================================== */
  const DOM = {
    appContainer: document.getElementById('appContainer'),
    precisionSelect: document.getElementById('precisionSelect'),
    soundToggle: document.getElementById('soundToggle'),
    soundIconOn: document.getElementById('soundIconOn'),
    soundIconOff: document.getElementById('soundIconOff'),
    themeToggle: document.getElementById('themeToggle'),
    themeIconSun: document.getElementById('themeIconSun'),
    themeIconMoon: document.getElementById('themeIconMoon'),
    historyPanelToggle: document.getElementById('historyPanelToggle'),
    historySidebar: document.getElementById('historySidebar'),
    closeSidebarBtn: document.getElementById('closeSidebarBtn'),
    clearHistoryBtn: document.getElementById('clearHistoryBtn'),
    exportHistoryBtn: document.getElementById('exportHistoryBtn'),
    clearHistoryBtnMobile: document.getElementById('clearHistoryBtnMobile'),
    exportHistoryBtnMobile: document.getElementById('exportHistoryBtnMobile'),
    sidebarHistoryList: document.getElementById('sidebarHistoryList'),
    mobileHistoryList: document.getElementById('mobileHistoryList'),
    historyCount: document.getElementById('historyCount'),
    toast: document.getElementById('toastNotification'),

    // Calculator Views
    calcDisplay: document.getElementById('calcDisplay'),
    expressionDisplay: document.getElementById('expressionDisplay'),
    resultDisplay: document.getElementById('resultDisplay'),
    livePreviewDisplay: document.getElementById('livePreviewDisplay'),
    angleUnitBadge: document.getElementById('angleUnitBadge'),
    memoryBadge: document.getElementById('memoryBadge'),
    evalErrorBadge: document.getElementById('evalErrorBadge'),
    copyResultBtn: document.getElementById('copyResultBtn'),
    scientificKeypad: document.getElementById('scientificKeypad'),
    angleToggleBtn: document.getElementById('angleToggleBtn'),
    secondFnToggle: document.getElementById('secondFnToggle'),

    // Converter
    convCategoryPills: document.getElementById('converterCategoryPills'),
    convInputVal: document.getElementById('convInputVal'),
    convFromUnit: document.getElementById('convFromUnit'),
    convOutputVal: document.getElementById('convOutputVal'),
    convToUnit: document.getElementById('convToUnit'),
    convSwapBtn: document.getElementById('convSwapBtn'),
    convFormulaText: document.getElementById('convFormulaText'),
    convCopyBtn: document.getElementById('convCopyBtn'),
    converterQuickTable: document.getElementById('converterQuickTable'),

    // Finance
    financeSubNav: document.getElementById('financeSubNav'),
    financeToolContent: document.getElementById('financeToolContent')
  };

  // Toast Helper
  let toastTimer = null;
  function showToast(message) {
    if (!DOM.toast) return;
    DOM.toast.textContent = message;
    DOM.toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      DOM.toast.classList.add('hidden');
    }, 2200);
  }

  // Copy to clipboard
  function copyText(text) {
    if (!text) return;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        showToast('Copied: ' + text);
      }).catch(() => fallbackCopy(text));
    } else {
      fallbackCopy(text);
    }
  }

  function fallbackCopy(text) {
    const input = document.createElement('textarea');
    input.value = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);
    showToast('Copied: ' + text);
  }

  // Update Theme
  function applyTheme(theme) {
    STATE.theme = theme;
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem('nexus_calc_theme', theme);

    if (theme === 'light') {
      DOM.themeIconSun.classList.remove('hidden');
      DOM.themeIconMoon.classList.add('hidden');
    } else {
      DOM.themeIconSun.classList.add('hidden');
      DOM.themeIconMoon.classList.remove('hidden');
    }
  }

  // Update Sound State
  function applySound(enabled) {
    STATE.soundEnabled = enabled;
    localStorage.setItem('nexus_calc_sound', enabled);
    if (enabled) {
      DOM.soundIconOn.classList.remove('hidden');
      DOM.soundIconOff.classList.add('hidden');
    } else {
      DOM.soundIconOn.classList.add('hidden');
      DOM.soundIconOff.classList.remove('hidden');
    }
  }

  // Update Precision
  function applyPrecision(precision) {
    STATE.precision = precision;
    localStorage.setItem('nexus_calc_precision', precision);
    updateCalculatorUI();
  }

  // Angle Mode (DEG/RAD)
  function toggleAngleMode() {
    STATE.angleMode = STATE.angleMode === 'DEG' ? 'RAD' : 'DEG';
    localStorage.setItem('nexus_calc_angle', STATE.angleMode);
    DOM.angleUnitBadge.textContent = STATE.angleMode;
    DOM.angleToggleBtn.textContent = STATE.angleMode === 'DEG' ? 'RAD' : 'DEG';
    playSound('click');
    updateLivePreview();
  }

  // 2nd Function Toggle
  function toggleSecondFunction() {
    STATE.isSecondFn = !STATE.isSecondFn;
    DOM.secondFnToggle.classList.toggle('active-state', STATE.isSecondFn);

    const trigBtns = document.querySelectorAll('.fn-trig');
    trigBtns.forEach(btn => {
      const fn = btn.getAttribute('data-fn');
      const inv = btn.getAttribute('data-inv');
      if (STATE.isSecondFn) {
        btn.textContent = inv === 'asin' ? 'sin⁻¹' : inv === 'acos' ? 'cos⁻¹' : 'tan⁻¹';
      } else {
        btn.textContent = fn;
      }
    });
    playSound('click');
  }

  /* ==========================================================================
     5. Calculator Input Logic
     ========================================================================== */

  function clearAll() {
    STATE.expression = '';
    STATE.result = '0';
    STATE.isEvaluated = false;
    STATE.hasError = false;
    DOM.evalErrorBadge.classList.add('hidden');
    playSound('click');
    updateCalculatorUI();
  }

  function backspace() {
    if (STATE.isEvaluated || STATE.hasError) {
      clearAll();
      return;
    }
    if (STATE.expression.length > 0) {
      // If ends with a function name like "sin(" or "log(", remove whole function
      const funcMatch = STATE.expression.match(/(sin|cos|tan|asin|acos|atan|log|ln|sqrt|cbrt|abs)\($/);
      if (funcMatch) {
        STATE.expression = STATE.expression.slice(0, -funcMatch[0].length);
      } else {
        STATE.expression = STATE.expression.slice(0, -1);
      }
      playSound('click');
      updateCalculatorUI();
    }
  }

  function inputDigit(digit) {
    if (STATE.isEvaluated || STATE.hasError) {
      STATE.expression = '';
      STATE.isEvaluated = false;
      STATE.hasError = false;
      DOM.evalErrorBadge.classList.add('hidden');
    }

    if (STATE.expression === '0' && digit !== '.') {
      STATE.expression = digit;
    } else {
      STATE.expression += digit;
    }

    playSound('click');
    updateCalculatorUI();
  }

  function inputDecimal() {
    if (STATE.isEvaluated || STATE.hasError) {
      STATE.expression = '0.';
      STATE.isEvaluated = false;
      STATE.hasError = false;
      DOM.evalErrorBadge.classList.add('hidden');
      playSound('click');
      updateCalculatorUI();
      return;
    }

    // Check last number segment to prevent duplicate dots
    const parts = STATE.expression.split(/[\+\−\×\÷\^\(\)]/);
    const lastPart = parts[parts.length - 1];
    if (lastPart.includes('.')) {
      playSound('error');
      return;
    }

    if (STATE.expression === '' || /[\+\−\×\÷\^\(]$/.test(STATE.expression)) {
      STATE.expression += '0.';
    } else {
      STATE.expression += '.';
    }

    playSound('click');
    updateCalculatorUI();
  }

  function inputOperator(op) {
    if (STATE.hasError) {
      clearAll();
    }

    if (STATE.isEvaluated) {
      // Chain operation from previous result
      STATE.expression = STATE.result;
      STATE.isEvaluated = false;
    }

    if (STATE.expression === '') {
      if (op === '−' || op === '-') {
        STATE.expression = '−';
        playSound('operator');
        updateCalculatorUI();
        return;
      }
      STATE.expression = '0';
    }

    // If last char is operator, replace it
    if (/[\+\−\×\÷\^]$/.test(STATE.expression)) {
      STATE.expression = STATE.expression.slice(0, -1) + op;
    } else {
      STATE.expression += op;
    }

    playSound('operator');
    updateCalculatorUI();
  }

  function inputFunction(fn) {
    if (STATE.isEvaluated || STATE.hasError) {
      STATE.expression = '';
      STATE.isEvaluated = false;
      STATE.hasError = false;
      DOM.evalErrorBadge.classList.add('hidden');
    }

    const actualFn = STATE.isSecondFn && (fn === 'sin' || fn === 'cos' || fn === 'tan')
      ? (fn === 'sin' ? 'asin' : fn === 'cos' ? 'acos' : 'atan')
      : fn;

    STATE.expression += actualFn + '(';
    playSound('operator');
    updateCalculatorUI();
  }

  function inputConstant(val) {
    if (STATE.isEvaluated || STATE.hasError) {
      STATE.expression = '';
      STATE.isEvaluated = false;
      STATE.hasError = false;
      DOM.evalErrorBadge.classList.add('hidden');
    }

    STATE.expression += val;
    playSound('click');
    updateCalculatorUI();
  }

  function inputParenthesis(type) {
    if (STATE.isEvaluated || STATE.hasError) {
      STATE.expression = '';
      STATE.isEvaluated = false;
      STATE.hasError = false;
      DOM.evalErrorBadge.classList.add('hidden');
    }

    STATE.expression += type;
    playSound('click');
    updateCalculatorUI();
  }

  function toggleSign() {
    if (STATE.isEvaluated) {
      STATE.expression = STATE.result;
      STATE.isEvaluated = false;
    }

    if (!STATE.expression || STATE.expression === '0') {
      STATE.expression = '−';
    } else if (STATE.expression.startsWith('−(') && STATE.expression.endsWith(')')) {
      STATE.expression = STATE.expression.slice(2, -1);
    } else {
      STATE.expression = `−(${STATE.expression})`;
    }

    playSound('operator');
    updateCalculatorUI();
  }

  function calculatePercent() {
    if (!STATE.expression) return;
    try {
      const val = safeCalculate(STATE.expression, STATE.angleMode);
      const res = val / 100;
      STATE.expression = res.toString();
      STATE.result = formatNumber(res, STATE.precision);
      playSound('operator');
      updateCalculatorUI();
    } catch (e) {
      triggerErrorShake();
    }
  }

  function applyQuickAction(act) {
    if (!STATE.expression && STATE.result !== '0') {
      STATE.expression = STATE.result;
    }
    if (!STATE.expression) return;

    switch (act) {
      case 'sqr':
        STATE.expression = `(${STATE.expression})^2`;
        break;
      case 'cube':
        STATE.expression = `(${STATE.expression})^3`;
        break;
      case 'reciprocal':
        STATE.expression = `1/(${STATE.expression})`;
        break;
      case 'factorial':
        STATE.expression = `(${STATE.expression})!`;
        break;
      case 'abs':
        STATE.expression = `abs(${STATE.expression})`;
        break;
      case 'tenpow':
        STATE.expression = `10^(${STATE.expression})`;
        break;
    }
    playSound('operator');
    updateCalculatorUI();
  }

  function evaluateExpression() {
    if (!STATE.expression || STATE.expression.trim() === '') return;

    try {
      const rawResult = safeCalculate(STATE.expression, STATE.angleMode);
      const formattedResult = formatNumber(rawResult, STATE.precision);

      // Save to History
      addHistoryItem({
        expression: STATE.expression,
        result: formattedResult,
        rawResult: rawResult,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });

      STATE.result = formattedResult;
      STATE.isEvaluated = true;
      STATE.hasError = false;
      DOM.evalErrorBadge.classList.add('hidden');
      playSound('equals');
      updateCalculatorUI();
    } catch (err) {
      STATE.hasError = true;
      STATE.result = err.message || 'Error';
      DOM.evalErrorBadge.classList.remove('hidden');
      triggerErrorShake();
      playSound('error');
      updateCalculatorUI();
    }
  }

  function triggerErrorShake() {
    DOM.calcDisplay.classList.remove('error-shake');
    void DOM.calcDisplay.offsetWidth; // Trigger reflow
    DOM.calcDisplay.classList.add('error-shake');
  }

  function updateLivePreview() {
    if (STATE.isEvaluated || STATE.hasError || !STATE.expression) {
      DOM.livePreviewDisplay.textContent = '';
      return;
    }

    try {
      // Auto close parentheses for preview
      let expr = STATE.expression;
      const openCount = (expr.match(/\(/g) || []).length;
      const closeCount = (expr.match(/\)/g) || []).length;
      if (openCount > closeCount) {
        expr += ')'.repeat(openCount - closeCount);
      }

      const preview = safeCalculate(expr, STATE.angleMode);
      DOM.livePreviewDisplay.textContent = '= ' + formatNumber(preview, STATE.precision);
    } catch (e) {
      DOM.livePreviewDisplay.textContent = '';
    }
  }

  function updateCalculatorUI() {
    DOM.expressionDisplay.textContent = STATE.expression;
    DOM.resultDisplay.textContent = STATE.result || '0';
    updateLivePreview();

    // Memory Indicator
    if (STATE.memory !== 0) {
      DOM.memoryBadge.classList.remove('hidden');
    } else {
      DOM.memoryBadge.classList.add('hidden');
    }
  }

  /* ==========================================================================
     6. Memory Operations (MC, MR, M+, M-, MS)
     ========================================================================== */
  function handleMemory(action) {
    const currentVal = parseFloat((STATE.isEvaluated ? STATE.result : STATE.expression) || '0');

    switch (action) {
      case 'MC':
        STATE.memory = 0;
        showToast('Memory Cleared (0)');
        break;
      case 'MR':
        if (STATE.isEvaluated) {
          STATE.expression = STATE.memory.toString();
          STATE.isEvaluated = false;
        } else {
          STATE.expression += STATE.memory.toString();
        }
        showToast('Recalled: ' + STATE.memory);
        break;
      case 'M+':
        STATE.memory += isNaN(currentVal) ? 0 : currentVal;
        showToast('Added to Memory: ' + STATE.memory);
        break;
      case 'M-':
        STATE.memory -= isNaN(currentVal) ? 0 : currentVal;
        showToast('Subtracted from Memory: ' + STATE.memory);
        break;
      case 'MS':
        STATE.memory = isNaN(currentVal) ? 0 : currentVal;
        showToast('Stored in Memory: ' + STATE.memory);
        break;
    }

    localStorage.setItem('nexus_calc_memory', STATE.memory.toString());
    playSound('click');
    updateCalculatorUI();
  }

  /* ==========================================================================
     7. History Management & Export
     ========================================================================== */
  function addHistoryItem(item) {
    STATE.history.unshift(item);
    if (STATE.history.length > 50) {
      STATE.history.pop();
    }
    localStorage.setItem('nexus_calc_history', JSON.stringify(STATE.history));
    renderHistory();
  }

  function clearHistory() {
    if (confirm('Clear all calculation history?')) {
      STATE.history = [];
      localStorage.removeItem('nexus_calc_history');
      renderHistory();
      showToast('History cleared');
      playSound('click');
    }
  }

  function deleteHistoryItem(index) {
    STATE.history.splice(index, 1);
    localStorage.setItem('nexus_calc_history', JSON.stringify(STATE.history));
    renderHistory();
    playSound('click');
  }

  function reuseHistory(item) {
    STATE.expression = item.expression;
    STATE.result = item.result;
    STATE.isEvaluated = false;
    STATE.hasError = false;
    DOM.evalErrorBadge.classList.add('hidden');
    updateCalculatorUI();
    showToast('Loaded into calculator');
    playSound('click');

    // Switch to standard tab if not already
    if (STATE.activeTab === 'history') {
      switchTab('standard');
    }
  }

  function exportHistory() {
    if (STATE.history.length === 0) {
      showToast('No history to export');
      return;
    }

    let csvContent = "data:text/csv;charset=utf-8,Time,Expression,Result\n";
    STATE.history.forEach(row => {
      csvContent += `"${row.timestamp}","${row.expression.replace(/"/g, '""')}","${row.result}"\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `nexus_calc_history_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('History exported as CSV');
  }

  function renderHistory() {
    const countText = `${STATE.history.length} calculation${STATE.history.length === 1 ? '' : 's'} saved`;
    DOM.historyCount.textContent = countText;

    const generateHTML = () => {
      if (STATE.history.length === 0) {
        return `
          <div class="history-empty-state">
            <svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.5">
              <circle cx="12" cy="12" r="10"></circle>
              <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
            <p>No calculations yet.<br>Solve an expression to log it here.</p>
          </div>
        `;
      }

      return STATE.history.map((item, idx) => `
        <div class="history-item" data-idx="${idx}">
          <div class="history-item-top">
            <span class="history-time">${item.timestamp}</span>
            <div class="history-item-actions">
              <button class="hist-action-btn copy-hist-btn" title="Copy result" data-res="${item.result}">Copy</button>
              <button class="hist-action-btn del-hist-btn" title="Delete" data-idx="${idx}">✕</button>
            </div>
          </div>
          <div class="history-expr">${item.expression}</div>
          <div class="history-res">= ${item.result}</div>
        </div>
      `).join('');
    };

    const html = generateHTML();
    DOM.sidebarHistoryList.innerHTML = html;
    DOM.mobileHistoryList.innerHTML = html;

    // Attach delegated click events
    [DOM.sidebarHistoryList, DOM.mobileHistoryList].forEach(container => {
      container.querySelectorAll('.history-item').forEach(el => {
        el.addEventListener('click', e => {
          if (e.target.closest('.hist-action-btn')) return;
          const idx = parseInt(el.getAttribute('data-idx'), 10);
          reuseHistory(STATE.history[idx]);
        });
      });

      container.querySelectorAll('.copy-hist-btn').forEach(btn => {
        btn.addEventListener('click', e => {
          e.stopPropagation();
          copyText(btn.getAttribute('data-res'));
        });
      });

      container.querySelectorAll('.del-hist-btn').forEach(btn => {
        btn.addEventListener('click', e => {
          e.stopPropagation();
          const idx = parseInt(btn.getAttribute('data-idx'), 10);
          deleteHistoryItem(idx);
        });
      });
    });
  }

  /* ==========================================================================
     8. Unit Converter Engine
     ========================================================================== */
  const CONVERTER_DATA = {
    length: {
      units: [
        { id: 'mm', name: 'Millimeters (mm)', factor: 0.001 },
        { id: 'cm', name: 'Centimeters (cm)', factor: 0.01 },
        { id: 'm', name: 'Meters (m)', factor: 1 },
        { id: 'km', name: 'Kilometers (km)', factor: 1000 },
        { id: 'in', name: 'Inches (in)', factor: 0.0254 },
        { id: 'ft', name: 'Feet (ft)', factor: 0.3048 },
        { id: 'yd', name: 'Yards (yd)', factor: 0.9144 },
        { id: 'mi', name: 'Miles (mi)', factor: 1609.344 }
      ],
      defaultFrom: 'm',
      defaultTo: 'cm'
    },
    weight: {
      units: [
        { id: 'mg', name: 'Milligrams (mg)', factor: 0.000001 },
        { id: 'g', name: 'Grams (g)', factor: 0.001 },
        { id: 'kg', name: 'Kilograms (kg)', factor: 1 },
        { id: 't', name: 'Metric Tonnes (t)', factor: 1000 },
        { id: 'oz', name: 'Ounces (oz)', factor: 0.0283495 },
        { id: 'lb', name: 'Pounds (lb)', factor: 0.45359237 }
      ],
      defaultFrom: 'kg',
      defaultTo: 'lb'
    },
    temp: {
      units: [
        { id: 'c', name: 'Celsius (°C)' },
        { id: 'f', name: 'Fahrenheit (°F)' },
        { id: 'k', name: 'Kelvin (K)' }
      ],
      defaultFrom: 'c',
      defaultTo: 'f'
    },
    speed: {
      units: [
        { id: 'mps', name: 'Meters / sec (m/s)', factor: 1 },
        { id: 'kmh', name: 'Kilometers / hour (km/h)', factor: 0.277778 },
        { id: 'mph', name: 'Miles / hour (mph)', factor: 0.44704 },
        { id: 'knot', name: 'Knots', factor: 0.514444 }
      ],
      defaultFrom: 'kmh',
      defaultTo: 'mph'
    },
    area: {
      units: [
        { id: 'sq_m', name: 'Square Meters (m²)', factor: 1 },
        { id: 'sq_km', name: 'Square Kilometers (km²)', factor: 1000000 },
        { id: 'sq_ft', name: 'Square Feet (ft²)', factor: 0.092903 },
        { id: 'acre', name: 'Acres', factor: 4046.86 },
        { id: 'hectare', name: 'Hectares', factor: 10000 }
      ],
      defaultFrom: 'sq_m',
      defaultTo: 'sq_ft'
    },
    volume: {
      units: [
        { id: 'ml', name: 'Milliliters (mL)', factor: 0.001 },
        { id: 'l', name: 'Liters (L)', factor: 1 },
        { id: 'm3', name: 'Cubic Meters (m³)', factor: 1000 },
        { id: 'floz', name: 'Fluid Ounces (fl oz)', factor: 0.0295735 },
        { id: 'gal', name: 'Gallons (US gal)', factor: 3.78541 }
      ],
      defaultFrom: 'l',
      defaultTo: 'gal'
    },
    time: {
      units: [
        { id: 'ms', name: 'Milliseconds (ms)', factor: 0.001 },
        { id: 's', name: 'Seconds (s)', factor: 1 },
        { id: 'min', name: 'Minutes (min)', factor: 60 },
        { id: 'hr', name: 'Hours (hr)', factor: 3600 },
        { id: 'day', name: 'Days', factor: 86400 },
        { id: 'wk', name: 'Weeks', factor: 604800 },
        { id: 'yr', name: 'Years (365d)', factor: 31536000 }
      ],
      defaultFrom: 'hr',
      defaultTo: 'min'
    },
    digital: {
      units: [
        { id: 'b', name: 'Bytes (B)', factor: 1 },
        { id: 'kb', name: 'Kilobytes (KB)', factor: 1024 },
        { id: 'mb', name: 'Megabytes (MB)', factor: 1048576 },
        { id: 'gb', name: 'Gigabytes (GB)', factor: 1073741824 },
        { id: 'tb', name: 'Terabytes (TB)', factor: 1099511627776 }
      ],
      defaultFrom: 'gb',
      defaultTo: 'mb'
    }
  };

  let currentConvCategory = 'length';

  function initConverter() {
    setConverterCategory(currentConvCategory);

    DOM.convCategoryPills.addEventListener('click', e => {
      const btn = e.target.closest('.cat-pill');
      if (!btn) return;
      DOM.convCategoryPills.querySelectorAll('.cat-pill').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      setConverterCategory(btn.getAttribute('data-cat'));
      playSound('click');
    });

    DOM.convInputVal.addEventListener('input', runConversion);
    DOM.convFromUnit.addEventListener('change', runConversion);
    DOM.convToUnit.addEventListener('change', runConversion);

    DOM.convSwapBtn.addEventListener('click', () => {
      const fromVal = DOM.convFromUnit.value;
      DOM.convFromUnit.value = DOM.convToUnit.value;
      DOM.convToUnit.value = fromVal;
      playSound('click');
      runConversion();
    });

    DOM.convCopyBtn.addEventListener('click', () => {
      copyText(DOM.convOutputVal.value);
    });
  }

  function setConverterCategory(cat) {
    currentConvCategory = cat;
    const catData = CONVERTER_DATA[cat];

    // Populate selects
    const optionsHTML = catData.units.map(u => `<option value="${u.id}">${u.name}</option>`).join('');
    DOM.convFromUnit.innerHTML = optionsHTML;
    DOM.convToUnit.innerHTML = optionsHTML;

    DOM.convFromUnit.value = catData.defaultFrom;
    DOM.convToUnit.value = catData.defaultTo;

    runConversion();
  }

  function runConversion() {
    const val = parseFloat(DOM.convInputVal.value);
    const from = DOM.convFromUnit.value;
    const to = DOM.convToUnit.value;

    if (isNaN(val)) {
      DOM.convOutputVal.value = '';
      DOM.convFormulaText.textContent = 'Enter a valid number';
      return;
    }

    let result = 0;
    const catData = CONVERTER_DATA[currentConvCategory];

    if (currentConvCategory === 'temp') {
      // Temperature conversion
      let celsius = 0;
      if (from === 'c') celsius = val;
      else if (from === 'f') celsius = (val - 32) * 5 / 9;
      else if (from === 'k') celsius = val - 273.15;

      if (to === 'c') result = celsius;
      else if (to === 'f') result = (celsius * 9 / 5) + 32;
      else if (to === 'k') result = celsius + 273.15;

      DOM.convFormulaText.textContent = `${val} ${from.toUpperCase()} = ${formatNumber(result, '4')} ${to.toUpperCase()}`;
    } else {
      // Linear factor conversion
      const fromObj = catData.units.find(u => u.id === from);
      const toObj = catData.units.find(u => u.id === to);

      if (fromObj && toObj) {
        const baseVal = val * fromObj.factor;
        result = baseVal / toObj.factor;

        const ratio = (fromObj.factor / toObj.factor);
        DOM.convFormulaText.textContent = `1 ${from} = ${formatNumber(ratio, '6')} ${to}`;
      }
    }

    DOM.convOutputVal.value = formatNumber(result, '6');
    renderQuickTable(catData, val, from);
  }

  function renderQuickTable(catData, val, fromUnitId) {
    const tbody = DOM.converterQuickTable.querySelector('tbody');
    if (!tbody) return;

    if (currentConvCategory === 'temp') {
      tbody.innerHTML = `
        <tr><td>Celsius</td><td>${formatNumber(fromUnitId === 'c' ? val : fromUnitId === 'f' ? (val - 32)*5/9 : val - 273.15, '2')} °C</td></tr>
        <tr><td>Fahrenheit</td><td>${formatNumber(fromUnitId === 'f' ? val : fromUnitId === 'c' ? (val*9/5)+32 : ((val-273.15)*9/5)+32, '2')} °F</td></tr>
        <tr><td>Kelvin</td><td>${formatNumber(fromUnitId === 'k' ? val : fromUnitId === 'c' ? val+273.15 : ((val-32)*5/9)+273.15, '2')} K</td></tr>
      `;
      return;
    }

    const fromObj = catData.units.find(u => u.id === fromUnitId);
    if (!fromObj) return;

    const baseVal = (isNaN(val) ? 1 : val) * fromObj.factor;

    tbody.innerHTML = catData.units
      .filter(u => u.id !== fromUnitId)
      .slice(0, 5)
      .map(u => {
        const converted = baseVal / u.factor;
        return `<tr><td>${u.name}</td><td>${formatNumber(converted, '4')}</td></tr>`;
      }).join('');
  }

  /* ==========================================================================
     9. Financial Suite
     ========================================================================== */
  const FINANCE_TOOLS = {
    emi: {
      render: () => `
        <div class="finance-form">
          <div class="finance-inputs">
            <div class="form-group">
              <label for="emiAmount">Loan Amount ($)</label>
              <input type="number" id="emiAmount" value="50000" class="calc-input">
            </div>
            <div class="form-group">
              <label for="emiRate">Annual Interest Rate (%)</label>
              <input type="number" id="emiRate" value="8.5" step="0.1" class="calc-input">
            </div>
            <div class="form-group">
              <label for="emiTenure">Tenure (Years)</label>
              <input type="number" id="emiTenure" value="5" class="calc-input">
            </div>
          </div>
          <div class="finance-results">
            <div class="result-card-primary">
              <div class="res-title">Monthly EMI</div>
              <div class="res-value" id="emiResult">$0</div>
            </div>
            <div class="result-grid-metrics">
              <div class="metric-row"><span>Principal Loan:</span><span id="emiPrincipal">$0</span></div>
              <div class="metric-row"><span>Total Interest:</span><span id="emiTotalInterest">$0</span></div>
              <div class="metric-row"><span>Total Payment:</span><span id="emiTotalPayment">$0</span></div>
            </div>
            <div class="ratio-bar-wrap">
              <div class="ratio-bar">
                <div id="emiRatioP" class="ratio-fill-a" style="width: 70%"></div>
                <div id="emiRatioI" class="ratio-fill-b" style="width: 30%"></div>
              </div>
              <div class="ratio-legend">
                <span><span class="legend-dot" style="background:var(--primary-accent)"></span>Principal (<span id="emiRatioPLabel">70%</span>)</span>
                <span><span class="legend-dot" style="background:var(--warning-color)"></span>Interest (<span id="emiRatioILabel">30%</span>)</span>
              </div>
            </div>
          </div>
        </div>
      `,
      calc: () => {
        const P = parseFloat(document.getElementById('emiAmount').value) || 0;
        const annualRate = parseFloat(document.getElementById('emiRate').value) || 0;
        const tenureYears = parseFloat(document.getElementById('emiTenure').value) || 0;

        const r = (annualRate / 12) / 100;
        const n = tenureYears * 12;

        let emi = 0;
        if (r > 0 && n > 0) {
          emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
        } else if (n > 0) {
          emi = P / n;
        }

        const totalPayment = emi * n;
        const totalInterest = totalPayment - P;

        document.getElementById('emiResult').textContent = '$' + formatNumber(emi, '2');
        document.getElementById('emiPrincipal').textContent = '$' + formatNumber(P, '2');
        document.getElementById('emiTotalInterest').textContent = '$' + formatNumber(totalInterest > 0 ? totalInterest : 0, '2');
        document.getElementById('emiTotalPayment').textContent = '$' + formatNumber(totalPayment > 0 ? totalPayment : P, '2');

        const pPercent = totalPayment > 0 ? Math.round((P / totalPayment) * 100) : 100;
        const iPercent = 100 - pPercent;
        document.getElementById('emiRatioP').style.width = pPercent + '%';
        document.getElementById('emiRatioI').style.width = iPercent + '%';
        document.getElementById('emiRatioPLabel').textContent = pPercent + '%';
        document.getElementById('emiRatioILabel').textContent = iPercent + '%';
      }
    },

    interest: {
      render: () => `
        <div class="finance-form">
          <div class="finance-inputs">
            <div class="form-group">
              <label for="intPrincipal">Principal Amount ($)</label>
              <input type="number" id="intPrincipal" value="10000" class="calc-input">
            </div>
            <div class="form-group">
              <label for="intRate">Annual Rate (%)</label>
              <input type="number" id="intRate" value="7.5" step="0.1" class="calc-input">
            </div>
            <div class="form-group">
              <label for="intTime">Time Period (Years)</label>
              <input type="number" id="intTime" value="3" class="calc-input">
            </div>
            <div class="form-group">
              <label for="intCompoundFreq">Compounding Frequency</label>
              <select id="intCompoundFreq" class="calc-select">
                <option value="1">Annually (1x/yr)</option>
                <option value="2">Semi-Annually (2x/yr)</option>
                <option value="4" selected>Quarterly (4x/yr)</option>
                <option value="12">Monthly (12x/yr)</option>
                <option value="365">Daily (365x/yr)</option>
              </select>
            </div>
          </div>
          <div class="finance-results">
            <div class="result-card-primary">
              <div class="res-title">Compound Total Amount</div>
              <div class="res-value" id="intCompoundTotal">$0</div>
            </div>
            <div class="result-grid-metrics">
              <div class="metric-row"><span>Simple Interest:</span><span id="intSimpleResult">$0</span></div>
              <div class="metric-row"><span>Compound Interest:</span><span id="intCompoundResult">$0</span></div>
              <div class="metric-row"><span>Compound Advantage:</span><span id="intDiffResult" style="color:var(--success-color)">+$0</span></div>
            </div>
          </div>
        </div>
      `,
      calc: () => {
        const P = parseFloat(document.getElementById('intPrincipal').value) || 0;
        const R = parseFloat(document.getElementById('intRate').value) || 0;
        const T = parseFloat(document.getElementById('intTime').value) || 0;
        const n = parseFloat(document.getElementById('intCompoundFreq').value) || 1;

        const simpleInt = (P * R * T) / 100;
        const compoundTotal = P * Math.pow(1 + (R / (100 * n)), n * T);
        const compoundInt = compoundTotal - P;
        const diff = compoundInt - simpleInt;

        document.getElementById('intCompoundTotal').textContent = '$' + formatNumber(compoundTotal, '2');
        document.getElementById('intSimpleResult').textContent = '$' + formatNumber(simpleInt, '2');
        document.getElementById('intCompoundResult').textContent = '$' + formatNumber(compoundInt, '2');
        document.getElementById('intDiffResult').textContent = '+$' + formatNumber(diff > 0 ? diff : 0, '2');
      }
    },

    gst: {
      render: () => `
        <div class="finance-form">
          <div class="finance-inputs">
            <div class="form-group">
              <label for="gstAmount">Amount ($)</label>
              <input type="number" id="gstAmount" value="1000" class="calc-input">
            </div>
            <div class="form-group">
              <label for="gstRate">Tax / GST Rate (%)</label>
              <input type="number" id="gstRate" value="18" class="calc-input">
            </div>
            <div class="form-group">
              <label>Calculation Type</label>
              <select id="gstType" class="calc-select">
                <option value="exclusive">Add GST (Exclusive)</option>
                <option value="inclusive">Remove GST (Inclusive)</option>
              </select>
            </div>
          </div>
          <div class="finance-results">
            <div class="result-card-primary">
              <div class="res-title">Final Gross Amount</div>
              <div class="res-value" id="gstGrossTotal">$0</div>
            </div>
            <div class="result-grid-metrics">
              <div class="metric-row"><span>Net Price:</span><span id="gstNetTotal">$0</span></div>
              <div class="metric-row"><span>Total GST / Tax:</span><span id="gstTaxAmount">$0</span></div>
              <div class="metric-row"><span>CGST / SGST (50/50 split):</span><span id="gstHalfSplit">$0 each</span></div>
            </div>
          </div>
        </div>
      `,
      calc: () => {
        const amount = parseFloat(document.getElementById('gstAmount').value) || 0;
        const rate = parseFloat(document.getElementById('gstRate').value) || 0;
        const isExclusive = document.getElementById('gstType').value === 'exclusive';

        let net = 0;
        let tax = 0;
        let gross = 0;

        if (isExclusive) {
          net = amount;
          tax = (amount * rate) / 100;
          gross = net + tax;
        } else {
          gross = amount;
          net = (amount * 100) / (100 + rate);
          tax = gross - net;
        }

        document.getElementById('gstGrossTotal').textContent = '$' + formatNumber(gross, '2');
        document.getElementById('gstNetTotal').textContent = '$' + formatNumber(net, '2');
        document.getElementById('gstTaxAmount').textContent = '$' + formatNumber(tax, '2');
        document.getElementById('gstHalfSplit').textContent = '$' + formatNumber(tax / 2, '2') + ' each';
      }
    },

    percent: {
      render: () => `
        <div class="finance-form">
          <div class="finance-inputs">
            <div class="form-group">
              <label for="pctInit">Initial Value</label>
              <input type="number" id="pctInit" value="250" class="calc-input">
            </div>
            <div class="form-group">
              <label for="pctFinal">Final Value</label>
              <input type="number" id="pctFinal" value="325" class="calc-input">
            </div>
          </div>
          <div class="finance-results">
            <div class="result-card-primary">
              <div class="res-title">Percentage Change</div>
              <div class="res-value" id="pctChangeValue">+0%</div>
            </div>
            <div class="result-grid-metrics">
              <div class="metric-row"><span>Absolute Difference:</span><span id="pctDiffValue">0</span></div>
              <div class="metric-row"><span>Trend:</span><span id="pctTrendLabel">Neutral</span></div>
            </div>
          </div>
        </div>
      `,
      calc: () => {
        const init = parseFloat(document.getElementById('pctInit').value) || 0;
        const finalVal = parseFloat(document.getElementById('pctFinal').value) || 0;

        const diff = finalVal - init;
        const pct = init !== 0 ? (diff / Math.abs(init)) * 100 : 0;

        const isInc = pct > 0;
        const sign = isInc ? '+' : '';
        document.getElementById('pctChangeValue').textContent = `${sign}${formatNumber(pct, '2')}%`;
        document.getElementById('pctDiffValue').textContent = formatNumber(diff, '2');

        const trendEl = document.getElementById('pctTrendLabel');
        if (pct > 0) {
          trendEl.textContent = 'Increase ↑';
          trendEl.style.color = 'var(--success-color)';
        } else if (pct < 0) {
          trendEl.textContent = 'Decrease ↓';
          trendEl.style.color = 'var(--danger-color)';
        } else {
          trendEl.textContent = 'No Change';
          trendEl.style.color = 'var(--text-muted)';
        }
      }
    },

    discount: {
      render: () => `
        <div class="finance-form">
          <div class="finance-inputs">
            <div class="form-group">
              <label for="discOriginal">Original Price ($)</label>
              <input type="number" id="discOriginal" value="120" class="calc-input">
            </div>
            <div class="form-group">
              <label for="discPercent">Discount Rate (%)</label>
              <input type="number" id="discPercent" value="25" class="calc-input">
            </div>
            <div class="form-group">
              <label for="discExtra">Extra Coupon Discount (%)</label>
              <input type="number" id="discExtra" value="5" class="calc-input">
            </div>
          </div>
          <div class="finance-results">
            <div class="result-card-primary">
              <div class="res-title">Final Price</div>
              <div class="res-value" id="discFinal">$0</div>
            </div>
            <div class="result-grid-metrics">
              <div class="metric-row"><span>You Save:</span><span id="discSavings" style="color:var(--success-color)">$0</span></div>
              <div class="metric-row"><span>Effective Discount:</span><span id="discEffectivePct">0%</span></div>
            </div>
          </div>
        </div>
      `,
      calc: () => {
        const orig = parseFloat(document.getElementById('discOriginal').value) || 0;
        const d1 = parseFloat(document.getElementById('discPercent').value) || 0;
        const d2 = parseFloat(document.getElementById('discExtra').value) || 0;

        const step1 = orig * (1 - d1 / 100);
        const finalPrice = step1 * (1 - d2 / 100);
        const totalSaved = orig - finalPrice;
        const effectivePct = orig > 0 ? (totalSaved / orig) * 100 : 0;

        document.getElementById('discFinal').textContent = '$' + formatNumber(finalPrice, '2');
        document.getElementById('discSavings').textContent = '$' + formatNumber(totalSaved, '2');
        document.getElementById('discEffectivePct').textContent = formatNumber(effectivePct, '1') + '%';
      }
    },

    profit: {
      render: () => `
        <div class="finance-form">
          <div class="finance-inputs">
            <div class="form-group">
              <label for="plCost">Cost Price (CP)</label>
              <input type="number" id="plCost" value="80" class="calc-input">
            </div>
            <div class="form-group">
              <label for="plSell">Selling Price (SP)</label>
              <input type="number" id="plSell" value="115" class="calc-input">
            </div>
          </div>
          <div class="finance-results">
            <div class="result-card-primary">
              <div class="res-title">Net Outcome</div>
              <div class="res-value" id="plNetValue">$0</div>
            </div>
            <div class="result-grid-metrics">
              <div class="metric-row"><span>Profit / Loss %:</span><span id="plPercent">0%</span></div>
              <div class="metric-row"><span>Profit Margin (% on SP):</span><span id="plMargin">0%</span></div>
            </div>
          </div>
        </div>
      `,
      calc: () => {
        const cp = parseFloat(document.getElementById('plCost').value) || 0;
        const sp = parseFloat(document.getElementById('plSell').value) || 0;

        const diff = sp - cp;
        const pct = cp > 0 ? (diff / cp) * 100 : 0;
        const margin = sp > 0 ? (diff / sp) * 100 : 0;

        const isProfit = diff >= 0;
        const valEl = document.getElementById('plNetValue');
        valEl.textContent = (isProfit ? '+$' : '-$') + formatNumber(Math.abs(diff), '2');
        valEl.style.color = isProfit ? 'var(--success-color)' : 'var(--danger-color)';

        document.getElementById('plPercent').textContent = (isProfit ? '+' : '') + formatNumber(pct, '2') + '%';
        document.getElementById('plMargin').textContent = formatNumber(margin, '2') + '%';
      }
    },

    sip: {
      render: () => `
        <div class="finance-form">
          <div class="finance-inputs">
            <div class="form-group">
              <label for="sipMonthly">Monthly Investment ($)</label>
              <input type="number" id="sipMonthly" value="500" class="calc-input">
            </div>
            <div class="form-group">
              <label for="sipRate">Expected Annual Return (%)</label>
              <input type="number" id="sipRate" value="12" step="0.5" class="calc-input">
            </div>
            <div class="form-group">
              <label for="sipYears">Time Period (Years)</label>
              <input type="number" id="sipYears" value="15" class="calc-input">
            </div>
          </div>
          <div class="finance-results">
            <div class="result-card-primary">
              <div class="res-title">Total Future Value</div>
              <div class="res-value" id="sipTotalValue">$0</div>
            </div>
            <div class="result-grid-metrics">
              <div class="metric-row"><span>Total Invested:</span><span id="sipInvested">$0</span></div>
              <div class="metric-row"><span>Estimated Wealth Gain:</span><span id="sipGain" style="color:var(--success-color)">$0</span></div>
            </div>
            <div class="ratio-bar-wrap">
              <div class="ratio-bar">
                <div id="sipRatioInv" class="ratio-fill-a" style="width: 35%"></div>
                <div id="sipRatioGain" class="ratio-fill-b" style="width: 65%"></div>
              </div>
              <div class="ratio-legend">
                <span>Invested (<span id="sipRatioInvLabel">35%</span>)</span>
                <span>Returns (<span id="sipRatioGainLabel">65%</span>)</span>
              </div>
            </div>
          </div>
        </div>
      `,
      calc: () => {
        const P = parseFloat(document.getElementById('sipMonthly').value) || 0;
        const annualRate = parseFloat(document.getElementById('sipRate').value) || 0;
        const years = parseFloat(document.getElementById('sipYears').value) || 0;

        const i = (annualRate / 12) / 100;
        const n = years * 12;

        let futureVal = 0;
        if (i > 0 && n > 0) {
          // Future value of SIP formula: P * [( (1+i)^n - 1 ) / i] * (1+i)
          futureVal = P * ((Math.pow(1 + i, n) - 1) / i) * (1 + i);
        } else {
          futureVal = P * n;
        }

        const invested = P * n;
        const gain = futureVal - invested;

        document.getElementById('sipTotalValue').textContent = '$' + formatNumber(futureVal, '0');
        document.getElementById('sipInvested').textContent = '$' + formatNumber(invested, '0');
        document.getElementById('sipGain').textContent = '+$' + formatNumber(gain > 0 ? gain : 0, '0');

        const invPct = futureVal > 0 ? Math.round((invested / futureVal) * 100) : 100;
        const gainPct = 100 - invPct;

        document.getElementById('sipRatioInv').style.width = invPct + '%';
        document.getElementById('sipRatioGain').style.width = gainPct + '%';
        document.getElementById('sipRatioInvLabel').textContent = invPct + '%';
        document.getElementById('sipRatioGainLabel').textContent = gainPct + '%';
      }
    }
  };

  function initFinance() {
    setFinanceSubTab(STATE.activeFinanceTab);

    DOM.financeSubNav.addEventListener('click', e => {
      const btn = e.target.closest('.sub-tab');
      if (!btn) return;
      DOM.financeSubNav.querySelectorAll('.sub-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      setFinanceSubTab(btn.getAttribute('data-sub'));
      playSound('click');
    });
  }

  function setFinanceSubTab(sub) {
    STATE.activeFinanceTab = sub;
    const tool = FINANCE_TOOLS[sub];
    if (!tool) return;

    DOM.financeToolContent.innerHTML = tool.render();
    tool.calc();

    // Attach real-time input listeners to all inputs/selects in this sub-tool
    DOM.financeToolContent.querySelectorAll('input, select').forEach(el => {
      el.addEventListener('input', tool.calc);
      el.addEventListener('change', tool.calc);
    });
  }

  /* ==========================================================================
     10. Navigation & Tabs
     ========================================================================== */
  function switchTab(tabId) {
    STATE.activeTab = tabId;

    // Update active tab button
    document.querySelectorAll('.nav-tab').forEach(btn => {
      const isTarget = btn.getAttribute('data-tab') === tabId;
      btn.classList.toggle('active', isTarget);
      btn.setAttribute('aria-selected', isTarget ? 'true' : 'false');
    });

    // View panels
    const calcView = document.getElementById('calcView');
    const converterView = document.getElementById('converterView');
    const financeView = document.getElementById('financeView');
    const historyView = document.getElementById('historyView');

    [calcView, converterView, financeView, historyView].forEach(panel => {
      if (panel) panel.classList.remove('active');
    });

    if (tabId === 'standard') {
      calcView.classList.add('active');
      DOM.scientificKeypad.classList.remove('visible');
    } else if (tabId === 'scientific') {
      calcView.classList.add('active');
      DOM.scientificKeypad.classList.add('visible');
    } else if (tabId === 'converter') {
      converterView.classList.add('active');
    } else if (tabId === 'finance') {
      financeView.classList.add('active');
    } else if (tabId === 'history') {
      historyView.classList.add('active');
    }

    playSound('click');
  }

  /* ==========================================================================
     11. Keyboard Support
     ========================================================================== */
  function initKeyboard() {
    window.addEventListener('keydown', e => {
      // Ignore if typing inside an input element (like converter or finance inputs)
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') {
        return;
      }

      const key = e.key;

      if (key >= '0' && key <= '9') {
        inputDigit(key);
        e.preventDefault();
      } else if (key === '.') {
        inputDecimal();
        e.preventDefault();
      } else if (key === '+' || key === '-' || key === '*' || key === '/' || key === '^') {
        const opMap = { '+': '+', '-': '−', '*': '×', '/': '÷', '^': '^' };
        inputOperator(opMap[key] || key);
        e.preventDefault();
      } else if (key === 'Enter' || key === '=') {
        evaluateExpression();
        e.preventDefault();
      } else if (key === 'Backspace') {
        backspace();
        e.preventDefault();
      } else if (key === 'Escape') {
        clearAll();
        e.preventDefault();
      } else if (key === '(' || key === ')') {
        inputParenthesis(key);
        e.preventDefault();
      } else if (key === '%') {
        calculatePercent();
        e.preventDefault();
      } else if (key.toLowerCase() === 's') {
        inputFunction('sin');
        e.preventDefault();
      } else if (key.toLowerCase() === 'c') {
        inputFunction('cos');
        e.preventDefault();
      } else if (key.toLowerCase() === 't') {
        inputFunction('tan');
        e.preventDefault();
      } else if (key.toLowerCase() === 'l') {
        inputFunction('log');
        e.preventDefault();
      } else if (key.toLowerCase() === 'n') {
        inputFunction('ln');
        e.preventDefault();
      } else if (key.toLowerCase() === 'p') {
        inputConstant('π');
        e.preventDefault();
      } else if (key.toLowerCase() === 'e') {
        inputConstant('e');
        e.preventDefault();
      }
    });
  }

  /* ==========================================================================
     12. Event Listeners & Bootstrapping
     ========================================================================== */
  function setupEventListeners() {
    // Theme toggle
    DOM.themeToggle.addEventListener('click', () => {
      applyTheme(STATE.theme === 'dark' ? 'light' : 'dark');
      playSound('click');
    });

    // Sound toggle
    DOM.soundToggle.addEventListener('click', () => {
      applySound(!STATE.soundEnabled);
      playSound('click');
    });

    // Precision selector
    DOM.precisionSelect.value = STATE.precision;
    DOM.precisionSelect.addEventListener('change', e => {
      applyPrecision(e.target.value);
      playSound('click');
    });

    // Copy result button
    DOM.copyResultBtn.addEventListener('click', () => {
      copyText(STATE.result);
      playSound('click');
    });

    // Angle toggle button
    DOM.angleToggleBtn.addEventListener('click', toggleAngleMode);

    // 2nd function toggle
    DOM.secondFnToggle.addEventListener('click', toggleSecondFunction);

    // History Sidebar toggle
    DOM.historyPanelToggle.addEventListener('click', () => {
      DOM.historySidebar.classList.toggle('collapsed');
      playSound('click');
    });

    if (DOM.closeSidebarBtn) {
      DOM.closeSidebarBtn.addEventListener('click', () => {
        DOM.historySidebar.classList.add('collapsed');
        playSound('click');
      });
    }

    // Clear and Export history
    DOM.clearHistoryBtn.addEventListener('click', clearHistory);
    DOM.exportHistoryBtn.addEventListener('click', exportHistory);
    if (DOM.clearHistoryBtnMobile) DOM.clearHistoryBtnMobile.addEventListener('click', clearHistory);
    if (DOM.exportHistoryBtnMobile) DOM.exportHistoryBtnMobile.addEventListener('click', exportHistory);

    // Navigation Tabs
    document.querySelector('.nav-tabs').addEventListener('click', e => {
      const tabBtn = e.target.closest('.nav-tab');
      if (tabBtn) {
        switchTab(tabBtn.getAttribute('data-tab'));
      }
    });

    // Keypad Click Delegation
    const handleKeypadAction = (btn) => {
      if (!btn) return;
      const action = btn.getAttribute('data-action');

      switch (action) {
        case 'num':
          inputDigit(btn.getAttribute('data-val'));
          break;
        case 'dot':
          inputDecimal();
          break;
        case 'operator':
          inputOperator(btn.getAttribute('data-val'));
          break;
        case 'fn':
          inputFunction(btn.getAttribute('data-fn'));
          break;
        case 'const':
          inputConstant(btn.getAttribute('data-val'));
          break;
        case 'paren-open':
          inputParenthesis('(');
          break;
        case 'paren-close':
          inputParenthesis(')');
          break;
        case 'percent':
          calculatePercent();
          break;
        case 'negate':
          toggleSign();
          break;
        case 'clear':
          clearAll();
          break;
        case 'backspace':
          backspace();
          break;
        case 'equals':
          evaluateExpression();
          break;
        case 'action':
          applyQuickAction(btn.getAttribute('data-act'));
          break;
      }
    };

    DOM.standardKeypad.addEventListener('click', e => {
      const btn = e.target.closest('.key-btn');
      handleKeypadAction(btn);
    });

    DOM.scientificKeypad.addEventListener('click', e => {
      const btn = e.target.closest('.sci-btn');
      if (btn && btn.id !== 'angleToggleBtn' && btn.id !== 'secondFnToggle') {
        handleKeypadAction(btn);
      }
    });

    // Memory bar
    document.querySelector('.memory-bar').addEventListener('click', e => {
      const btn = e.target.closest('.mem-btn');
      if (btn) {
        handleMemory(btn.getAttribute('data-mem'));
      }
    });
  }

  // PWA Service Worker Registration
  function registerServiceWorker() {
    if ('serviceWorker' in navigator && window.location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('sw.js').catch(err => {
        console.log('SW registration skipped or error:', err);
      });
    }
  }

  // App Initialization
  function init() {
    applyTheme(STATE.theme);
    applySound(STATE.soundEnabled);
    DOM.angleUnitBadge.textContent = STATE.angleMode;
    DOM.angleToggleBtn.textContent = STATE.angleMode === 'DEG' ? 'RAD' : 'DEG';

    setupEventListeners();
    initKeyboard();
    initConverter();
    initFinance();
    renderHistory();
    updateCalculatorUI();
    registerServiceWorker();
  }

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
