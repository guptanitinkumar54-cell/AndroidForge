package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NEXUS CALC", appName)
  }

  @Test
  fun `verify assets are bundled`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val assetManager = context.assets
    val assetsList = assetManager.list("")?.toList() ?: emptyList()
    assertTrue(assetsList.contains("index.html"))
    assertTrue(assetsList.contains("style.css"))
    assertTrue(assetsList.contains("script.js"))
  }

  @Test
  fun `verify main activity launches without crash`() {
    val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java)
    controller.setup()
    val activity = controller.get()
    org.junit.Assert.assertNotNull(activity)
  }
}
