package com.example

import com.example.calc.FinanceEngine
import com.example.calc.MathEngine
import com.example.calc.UnitConverter
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.PI

class CalculatorEngineTest {

  @Test
  fun testBasicArithmetic() {
    assertEquals(14.0, MathEngine.evaluate("2 + 3 * 4"), 1e-9)
    assertEquals(20.0, MathEngine.evaluate("(2 + 3) * 4"), 1e-9)
    assertEquals(2.5, MathEngine.evaluate("5 / 2"), 1e-9)
    assertEquals(1.0, MathEngine.evaluate("7 % 3"), 1e-9)
    assertEquals(1.0, MathEngine.evaluate("7 mod 3"), 1e-9)
  }

  @Test
  fun testOperatorPrecedenceAndAssociativity() {
    // Exponentiation is right-associative: 2 ^ 3 ^ 2 = 2 ^ 9 = 512
    assertEquals(512.0, MathEngine.evaluate("2 ^ 3 ^ 2"), 1e-9)
    assertEquals(64.0, MathEngine.evaluate("(2 ^ 3) ^ 2"), 1e-9)

    // Unary minus vs power: -5^2 = -25, (-5)^2 = 25
    assertEquals(-25.0, MathEngine.evaluate("-5^2"), 1e-9)
    assertEquals(25.0, MathEngine.evaluate("(-5)^2"), 1e-9)

    // Unary minus in products
    assertEquals(-6.0, MathEngine.evaluate("2 * -3"), 1e-9)
    assertEquals(-6.0, MathEngine.evaluate("-3 * 2"), 1e-9)
    assertEquals(7.0, MathEngine.evaluate("4 - -3"), 1e-9)
  }

  @Test
  fun testImplicitMultiplication() {
    assertEquals(6.0, MathEngine.evaluate("2(3)"), 1e-9)
    assertEquals(20.0, MathEngine.evaluate("(2 + 3)(4)"), 1e-9)
    assertEquals(2.0 * PI, MathEngine.evaluate("2pi"), 1e-9)
  }

  @Test
  fun testAutoParenthesesBalancing() {
    assertEquals(8.0, MathEngine.evaluate("(5 + 3"), 1e-9)
    assertEquals(15.0, MathEngine.evaluate("((2 + 3) * 3"), 1e-9)
  }

  @Test
  fun testScientificFunctions() {
    // Trig DEG
    assertEquals(0.5, MathEngine.evaluate("sin(30)", isDegreeMode = true), 1e-9)
    assertEquals(0.5, MathEngine.evaluate("cos(60)", isDegreeMode = true), 1e-9)
    assertEquals(1.0, MathEngine.evaluate("tan(45)", isDegreeMode = true), 1e-9)

    // Trig RAD
    assertEquals(0.5, MathEngine.evaluate("sin(pi / 6)", isDegreeMode = false), 1e-9)
    assertEquals(0.0, MathEngine.evaluate("sin(0)", isDegreeMode = true), 1e-9)
    assertEquals(1.0, MathEngine.evaluate("cos(0)", isDegreeMode = true), 1e-9)

    // Inverse Trig
    assertEquals(30.0, MathEngine.evaluate("asin(0.5)", isDegreeMode = true), 1e-9)
    assertEquals(60.0, MathEngine.evaluate("acos(0.5)", isDegreeMode = true), 1e-9)
    assertEquals(45.0, MathEngine.evaluate("atan(1)", isDegreeMode = true), 1e-9)

    // Logarithms
    assertEquals(2.0, MathEngine.evaluate("log(100)"), 1e-9)
    assertEquals(1.0, MathEngine.evaluate("ln(e)"), 1e-9)

    // Roots & Powers
    assertEquals(4.0, MathEngine.evaluate("sqrt(16)"), 1e-9)
    assertEquals(3.0, MathEngine.evaluate("cbrt(27)"), 1e-9)

    // Factorials
    assertEquals(120.0, MathEngine.evaluate("5!"), 1e-9)
    assertEquals(1.0, MathEngine.evaluate("0!"), 1e-9)
    assertEquals(720.0, MathEngine.evaluate("6!"), 1e-9)

    // Absolute
    assertEquals(15.0, MathEngine.evaluate("abs(-15)"), 1e-9)
  }

  @Test
  fun testDomainExceptions() {
    // Division by zero
    assertThrows(ArithmeticException::class.java) {
      MathEngine.evaluate("5 / 0")
    }

    // Sqrt negative
    assertThrows(ArithmeticException::class.java) {
      MathEngine.evaluate("sqrt(-4)")
    }

    // Log non-positive
    assertThrows(ArithmeticException::class.java) {
      MathEngine.evaluate("log(0)")
    }
    assertThrows(ArithmeticException::class.java) {
      MathEngine.evaluate("ln(-5)")
    }

    // Asin domain
    assertThrows(ArithmeticException::class.java) {
      MathEngine.evaluate("asin(2)")
    }

    // Tan 90 deg
    assertThrows(ArithmeticException::class.java) {
      MathEngine.evaluate("tan(90)", isDegreeMode = true)
    }

    // Negative factorial
    assertThrows(IllegalArgumentException::class.java) {
      MathEngine.evaluate("(-3)!")
    }
  }

  @Test
  fun testNumberFormatting() {
    assertEquals("1,234,567", MathEngine.formatNumber(1234567.0, "auto"))
    assertEquals("1,234.56", MathEngine.formatNumber(1234.56, "2"))
    assertEquals("1,234.5600", MathEngine.formatNumber(1234.56, "4"))
  }

  @Test
  fun testUnitConverter() {
    // Length
    assertEquals(100.0, UnitConverter.convert("length", 1.0, "m", "cm"), 1e-9)
    assertEquals(1.0, UnitConverter.convert("length", 1000.0, "m", "km"), 1e-9)
    assertEquals(12.0, UnitConverter.convert("length", 1.0, "ft", "in"), 1e-4)

    // Temperature
    assertEquals(32.0, UnitConverter.convert("temp", 0.0, "c", "f"), 1e-9)
    assertEquals(212.0, UnitConverter.convert("temp", 100.0, "c", "f"), 1e-9)
    assertEquals(100.0, UnitConverter.convert("temp", 212.0, "f", "c"), 1e-9)
    assertEquals(273.15, UnitConverter.convert("temp", 0.0, "c", "k"), 1e-9)

    // Digital
    assertEquals(1024.0, UnitConverter.convert("digital", 1.0, "gb", "mb"), 1e-9)
    assertEquals(1048576.0, UnitConverter.convert("digital", 1.0, "mb", "b"), 1e-9)

    // Weight
    assertEquals(1000.0, UnitConverter.convert("weight", 1.0, "kg", "g"), 1e-9)
  }

  @Test
  fun testFinancialCalculations() {
    // EMI: $50,000 at 8.5% for 5 years
    val emi = FinanceEngine.calculateEmi(50000.0, 8.5, 5.0)
    assertEquals(1025.83, emi.emi, 0.5)
    assertTrue(emi.totalPayment > 50000.0)

    // Interest: $10,000 at 7.5% for 3 years, quarterly (n=4)
    val interest = FinanceEngine.calculateInterest(10000.0, 7.5, 3.0, 4)
    assertEquals(2250.0, interest.simpleInterest, 1e-2)
    assertEquals(12497.16, interest.compoundTotal, 0.5)
    assertTrue(interest.compoundAdvantage > 0.0)

    // GST
    val gstExclusive = FinanceEngine.calculateGst(1000.0, 18.0, true)
    assertEquals(1000.0, gstExclusive.net, 1e-2)
    assertEquals(180.0, gstExclusive.tax, 1e-2)
    assertEquals(1180.0, gstExclusive.gross, 1e-2)
    assertEquals(90.0, gstExclusive.cgst, 1e-2)

    val gstInclusive = FinanceEngine.calculateGst(1180.0, 18.0, false)
    assertEquals(1000.0, gstInclusive.net, 1e-2)
    assertEquals(180.0, gstInclusive.tax, 1e-2)

    // Discount: $120 with 25% discount and extra 5% coupon
    val disc = FinanceEngine.calculateDiscount(120.0, 25.0, 5.0)
    assertEquals(85.50, disc.finalPrice, 1e-2)
    assertEquals(34.50, disc.totalSavings, 1e-2)

    // Profit & Loss: CP=80, SP=115
    val pl = FinanceEngine.calculateProfitLoss(80.0, 115.0)
    assertTrue(pl.isProfit)
    assertEquals(35.0, pl.diff, 1e-2)
    assertEquals(43.75, pl.pct, 1e-2)

    // SIP: $500/month, 12% annual return, 15 years
    val sip = FinanceEngine.calculateSip(500.0, 12.0, 15.0)
    assertEquals(90000.0, sip.invested, 1e-2)
    assertTrue(sip.futureValue > 250000.0)
    assertTrue(sip.gain > 160000.0)
  }
}
